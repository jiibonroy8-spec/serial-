ALTER TABLE public.call_recordings DROP CONSTRAINT IF EXISTS call_recordings_status_check;
ALTER TABLE public.call_recordings ADD CONSTRAINT call_recordings_status_check
  CHECK (processing_status IN ('uploaded','processing','transcribed','processed','serial_created','needs_review','dismissed','failed'));