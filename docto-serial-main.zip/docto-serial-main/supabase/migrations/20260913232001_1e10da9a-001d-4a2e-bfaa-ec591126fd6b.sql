CREATE OR REPLACE FUNCTION public.add_drum_serial(
  _customer_name text,
  _village text DEFAULT NULL,
  _mobile_number text DEFAULT NULL,
  _drum_number text DEFAULT NULL,
  _source text DEFAULT 'manual',
  _call_recording_id uuid DEFAULT NULL
)
RETURNS public.drums
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  _next integer;
  _row public.drums;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('drums_serial_number'));
  SELECT COALESCE(MAX(serial_number), 0) + 1 INTO _next FROM public.drums;
  INSERT INTO public.drums (serial_number, customer_name, village, mobile_number, drum_number, source, call_recording_id)
  VALUES (_next, _customer_name, NULLIF(_village, ''), NULLIF(_mobile_number, ''), NULLIF(_drum_number, ''), COALESCE(NULLIF(_source, ''), 'manual'), _call_recording_id)
  RETURNING * INTO _row;
  RETURN _row;
END;
$$;