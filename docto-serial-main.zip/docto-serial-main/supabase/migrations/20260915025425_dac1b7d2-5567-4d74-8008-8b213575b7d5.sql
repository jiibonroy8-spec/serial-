CREATE OR REPLACE FUNCTION public.remember_serial_suggestion(_kind text, _value text)
RETURNS public.serial_suggestions
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  _row public.serial_suggestions;
BEGIN
  INSERT INTO public.serial_suggestions (kind, value)
  VALUES (_kind, _value)
  ON CONFLICT (kind, value) DO NOTHING
  RETURNING * INTO _row;

  IF _row.id IS NULL THEN
    SELECT * INTO _row
    FROM public.serial_suggestions
    WHERE kind = _kind AND value ILIKE _value
    ORDER BY created_at DESC
    LIMIT 1;
  END IF;

  RETURN _row;
END;
$$;