import { createServerFn } from "@tanstack/react-start";

export type CallRecording = {
  id: string;
  original_filename: string;
  file_size: number;
  processing_status: string;
  transcript: string | null;
  extracted_name: string | null;
  extracted_village: string | null;
  extracted_mobile: string | null;
  error_message: string | null;
  drum_id: string | null;
  created_at: string;
};

const SELECT =
  "id, original_filename, file_size, processing_status, transcript, extracted_name, extracted_village, extracted_mobile, error_message, drum_id, created_at";

export const listCallRecordings = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("call_recordings")
    .select(SELECT)
    .order("created_at", { ascending: false })
    .limit(100);
  if (error) throw new Error(error.message);
  return (data ?? []) as CallRecording[];
});

function base64ToBytes(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function rememberSuggestion(kind: "name" | "village" | "mobile", value: string | null) {
  if (!value) return;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { error } = await supabaseAdmin.rpc("remember_serial_suggestion", {
    _kind: kind,
    _value: value,
  });
  if (error) console.warn(`[call-recordings] suggestion save failed: ${error.message}`);
}

/** Transcribe + extract + (when possible) create the serial. */
async function runPipeline(recordingId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const {
    transcribeBengali,
    extractPatientDetails,
    normaliseMobile,
    mobileFromFilename,
  } = await import("./call-recordings.server");

  const { data: rec, error } = await supabaseAdmin
    .from("call_recordings")
    .select("id, storage_path, original_filename, file_type, processing_status, drum_id")
    .eq("id", recordingId)
    .single();
  if (error || !rec) throw new Error(error?.message ?? "recording_not_found");
  if (rec.drum_id) return { status: "serial_created" as const, recordingId };

  // Reconcile: the serial may have been created while a previous run was cut short.
  const { data: existingDrum } = await supabaseAdmin
    .from("drums")
    .select("id")
    .eq("call_recording_id", recordingId)
    .maybeSingle();
  if (existingDrum) {
    await supabaseAdmin
      .from("call_recordings")
      .update({ processing_status: "serial_created", drum_id: existingDrum.id, error_message: null })
      .eq("id", recordingId);
    return { status: "serial_created" as const, recordingId };
  }

  await supabaseAdmin
    .from("call_recordings")
    .update({ processing_status: "processing", error_message: null })
    .eq("id", recordingId);

  try {
    const { data: file, error: dlError } = await supabaseAdmin.storage
      .from("call-recordings")
      .download(rec.storage_path);
    if (dlError || !file) throw new Error(dlError?.message ?? "download_failed");

    const bytes = await file.arrayBuffer();
    const transcript = await transcribeBengali(bytes, rec.original_filename, rec.file_type);
    const extracted = transcript
      ? await extractPatientDetails(transcript)
      : { name: null, village: null, mobile: null };
    // The number always comes from the recording's filename, never from the speech.
    const mobile = mobileFromFilename(rec.original_filename) ?? normaliseMobile(extracted.mobile);

    // Only the name is mandatory — village and number may be missing.
    if (!extracted.name) {
      await supabaseAdmin
        .from("call_recordings")
        .update({
          transcript,
          extracted_name: extracted.name,
          extracted_village: extracted.village,
          extracted_mobile: mobile,
          processing_status: "needs_review",
          review_note: !transcript ? "কথা শনাক্ত হয়নি" : "নাম পাওয়া যায়নি",
        })
        .eq("id", recordingId);
      return { status: "needs_review" as const, recordingId };
    }


    const { data: drum, error: rpcError } = await supabaseAdmin.rpc("add_drum_serial", {
      _customer_name: extracted.name,
      _village: extracted.village ?? undefined,
      _mobile_number: mobile ?? undefined,
      _source: "call_recording",
      _call_recording_id: recordingId,
    });
    if (rpcError) throw new Error(rpcError.message);

    await supabaseAdmin
      .from("call_recordings")
      .update({
        transcript,
        extracted_name: extracted.name,
        extracted_village: extracted.village,
        extracted_mobile: mobile,
        processing_status: "serial_created",
        drum_id: (drum as { id: string }).id,
        review_note: null,
      })
      .eq("id", recordingId);

    await rememberSuggestion("name", extracted.name);
    await rememberSuggestion("village", extracted.village);
    await rememberSuggestion("mobile", mobile);

    return { status: "serial_created" as const, recordingId, drum: drum as { id: string } };
  } catch (err) {
    const message = err instanceof Error ? err.message : "unknown_error";
    console.error(`[call-recordings] processing failed id=${recordingId}: ${message}`);
    await supabaseAdmin
      .from("call_recordings")
      .update({ processing_status: "failed", error_message: message.slice(0, 500) })
      .eq("id", recordingId);
    return { status: "failed" as const, recordingId, message };
  }
}

export const uploadCallRecording = createServerFn({ method: "POST" })
  .inputValidator((data: { base64: string; filename: string; fileType: string }) => {
    if (typeof data?.base64 !== "string" || !data.base64) throw new Error("missing_file");
    return {
      base64: data.base64,
      filename: typeof data.filename === "string" ? data.filename : "recording.m4a",
      fileType: typeof data.fileType === "string" ? data.fileType : "audio/m4a",
    };
  })
  .handler(async ({ data }) => {
    const { storeRecording } = await import("./call-recordings.server");
    const stored = await storeRecording({
      bytes: base64ToBytes(data.base64),
      filename: data.filename,
      fileType: data.fileType,
    });
    if (!stored.ok) return { ok: false as const, error: stored.error };
    if (stored.duplicate) {
      // Finish an earlier run that never completed; otherwise this is a no-op.
      const again = await runPipeline(stored.recordingId);
      return {
        ok: true as const,
        duplicate: true,
        recordingId: stored.recordingId,
        status: again.status === "serial_created" ? "duplicate" : again.status,
      };
    }
    const result = await runPipeline(stored.recordingId);
    return { ok: true as const, duplicate: false, recordingId: stored.recordingId, status: result.status };
  });

export const processCallRecording = createServerFn({ method: "POST" })
  .inputValidator((data: { id: string }) => {
    if (typeof data?.id !== "string" || !data.id) throw new Error("missing_id");
    return { id: data.id };
  })
  .handler(async ({ data }) => runPipeline(data.id));

export const processPendingRecordings = createServerFn({ method: "POST" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("call_recordings")
    .select("id")
    .in("processing_status", ["uploaded", "failed", "processing"])
    .order("created_at", { ascending: true })
    .limit(10);
  if (error) throw new Error(error.message);
  const results = [];
  for (const row of data ?? []) results.push(await runPipeline(row.id));
  return { processed: results.length, results };
});

/** Manual correction of a needs_review recording → creates the serial. */
export const confirmCallRecording = createServerFn({ method: "POST" })
  .inputValidator((data: { id: string; name: string; village?: string; mobile: string }) => ({
    id: String(data?.id ?? ""),
    name: String(data?.name ?? "").trim(),
    village: String(data?.village ?? "").trim(),
    mobile: String(data?.mobile ?? "").trim(),
  }))
  .handler(async ({ data }) => {
    const { normaliseMobile } = await import("./call-recordings.server");
    const mobile = normaliseMobile(data.mobile);
    // Name is the only required field; village and number are optional.
    if (!data.id || !data.name) return { ok: false as const, error: "invalid_input" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: drum, error } = await supabaseAdmin.rpc("add_drum_serial", {
      _customer_name: data.name,
      _village: data.village || undefined,
      _mobile_number: mobile ?? undefined,
      _source: "call_recording",
      _call_recording_id: data.id,
    });
    if (error) return { ok: false as const, error: error.message };

    await supabaseAdmin
      .from("call_recordings")
      .update({
        extracted_name: data.name,
        extracted_village: data.village || null,
        extracted_mobile: mobile,
        processing_status: "serial_created",
        drum_id: (drum as { id: string }).id,
        review_note: null,
      })
      .eq("id", data.id);

    await rememberSuggestion("name", data.name);
    await rememberSuggestion("village", data.village || null);
    await rememberSuggestion("mobile", mobile);

    return { ok: true as const, drum: drum as { id: string; serial_number: number } };
  });

export const dismissCallRecording = createServerFn({ method: "POST" })
  .inputValidator((data: { id: string }) => ({ id: String(data?.id ?? "") }))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("call_recordings")
      .update({ processing_status: "dismissed" })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
