import type { Drum } from "@/hooks/use-drums";

// Chamber days: 0=Sun, 1=Mon, ... 6=Sat
// Chamber days: Sun(0), Tue(2), Wed(3), Fri(5)
// Sun/Tue/Wed: 15:00 - 18:00, 2.4 min/patient
// Fri: 10:00 - 19:00, 4.3 min/patient

type ChamberSchedule = {
  startHour: number;
  startMin: number;
  endHour: number;
  endMin: number;
  minPerPatient: number;
};

const PER_PATIENT_MIN = 2; // প্রতি রোগীর জন্য ২ মিনিট

const SCHEDULES: Record<number, ChamberSchedule> = {
  0: { startHour: 15, startMin: 0, endHour: 18, endMin: 0, minPerPatient: PER_PATIENT_MIN }, // Sun
  2: { startHour: 15, startMin: 0, endHour: 18, endMin: 0, minPerPatient: PER_PATIENT_MIN }, // Tue
  3: { startHour: 15, startMin: 0, endHour: 18, endMin: 0, minPerPatient: PER_PATIENT_MIN }, // Wed
  5: { startHour: 10, startMin: 0, endHour: 19, endMin: 0, minPerPatient: PER_PATIENT_MIN }, // Fri
};

const CHAMBER_DAYS = [0, 2, 3, 5];

const BENGALI_DIGITS = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
export function toBn(n: number | string): string {
  return String(n).replace(/[0-9]/g, (d) => BENGALI_DIGITS[Number(d)]);
}

const BN_WEEKDAY = ["রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"];

/** Return the target chamber-day (a Date at 00:00) for a given entry date. */
export function targetChamberDay(date: Date): Date {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  for (let i = 0; i < 7; i++) {
    const probe = new Date(d);
    probe.setDate(d.getDate() + i);
    if (CHAMBER_DAYS.includes(probe.getDay())) return probe;
  }
  return d;
}

export function chamberDayKey(date: Date): string {
  const t = targetChamberDay(date);
  return `${t.getFullYear()}-${t.getMonth() + 1}-${t.getDate()}`;
}

/** Count of entries whose target chamber-day matches this one's, including itself. Sorted by created_at ascending; 1-based position. */
export function computeChamberSerial(drum: Drum, allDrums: Drum[]): number {
  const key = chamberDayKey(new Date(drum.created_at));
  const sameDay = allDrums
    .filter((d) => chamberDayKey(new Date(d.created_at)) === key)
    .sort((a, b) => +new Date(a.created_at) - +new Date(b.created_at));
  const idx = sameDay.findIndex((d) => d.id === drum.id);
  return idx >= 0 ? idx + 1 : sameDay.length + 1;
}

/** Format time in Bengali like "বিকাল ৪টা" or "সকাল ১০টা ২০". */
export function formatBnTime(h: number, m: number): string {
  let period: string;
  if (h < 12) period = "সকাল";
  else if (h < 15) period = "দুপুর";
  else if (h < 18) period = "বিকাল";
  else period = "সন্ধ্যা";

  let hour12 = h % 12;
  if (hour12 === 0) hour12 = 12;

  const hourBn = toBn(hour12);
  if (m === 0) return `${period} ${hourBn}টা`;
  return `${period} ${hourBn}টা ${toBn(m)}`;
}

export type SmsInfo = {
  serial: number;
  chamberDay: Date;
  chamberDayLabel: string;
  chamberTime: string;
  estTime: string;
  overflow: boolean;
};

export function computeSmsInfo(drum: Drum, allDrums: Drum[]): SmsInfo {
  const serial = computeChamberSerial(drum, allDrums);
  const chamberDay = targetChamberDay(new Date(drum.created_at));
  const dow = chamberDay.getDay();
  const sched = SCHEDULES[dow] ?? SCHEDULES[0];
  const totalMin = sched.startHour * 60 + sched.startMin + (serial - 1) * sched.minPerPatient;
  const h = Math.floor(totalMin / 60);
  const m = Math.round(totalMin % 60);
  const endMin = sched.endHour * 60 + sched.endMin;
  const overflow = totalMin > endMin;
  const chamberTime = `${formatBnTime(sched.startHour, sched.startMin)} - ${formatBnTime(sched.endHour, sched.endMin)}`;
  return {
    serial,
    chamberDay,
    chamberDayLabel: BN_WEEKDAY[dow],
    chamberTime,
    estTime: formatBnTime(h % 24, m),
    overflow,
  };
}

export const DEFAULT_SMS_TEMPLATE =
  `{patient_name}, সিরিয়াল: {serial}, ডা. পরিমল রায়, আস্থা ফার্মেসি, পীরগঞ্জ, 01763115115`;

export const DEFAULT_NEXT_SMS_TEMPLATE =
  `{patient_name}, আপনার সিরিয়াল #{serial} পরবর্তী সিরিয়াল আপনার।। অনুগ্রহ করে চেম্বারে চলে আসুন।

— আস্থা ফার্মেসী`;

export function renderSms(template: string, drum: Drum, allDrums: Drum[]): { message: string; info: SmsInfo } {
  const info = computeSmsInfo(drum, allDrums);
  const message = applyPlaceholders(template, {
    name: drum.customer_name,
    serial: toBn(drum.serial_number),
    est_time: info.estTime,
    chamber_day: info.chamberDayLabel,
    chamber_time: info.chamberTime,
  });
  return { message, info };
}

/** Replace both {key} and {{key}} placeholders. Accepts `name` / `patient_name` as aliases. */
export function applyPlaceholders(
  template: string,
  vars: { name?: string; serial?: string | number; est_time?: string; chamber_day?: string; chamber_time?: string },
): string {
  const map: Record<string, string> = {
    name: String(vars.name ?? ""),
    patient_name: String(vars.name ?? ""),
    serial: String(vars.serial ?? ""),
    est_time: String(vars.est_time ?? ""),
    chamber_day: String(vars.chamber_day ?? ""),
    chamber_time: String(vars.chamber_time ?? ""),
  };
  return template.replace(/\{\{?\s*(\w+)\s*\}?\}/g, (m, key) =>
    Object.prototype.hasOwnProperty.call(map, key) ? map[key] : m,
  );
}

/** Preview a template with dummy values ("সুমা" / "৩৫"). */
export function previewSms(template: string): string {
  return applyPlaceholders(template, {
    name: "সুমা",
    serial: "৩৫",
    est_time: "বিকাল ৫টা",
    chamber_day: "রবিবার",
    chamber_time: "বিকাল ৩টা - বিকাল ৬টা",
  });
}
