// Fire-and-forget Google Sheets backup. Never throws.
// The webhook URL lives in settings (localStorage) so the user can change it
// without touching code.

const DEFAULT_WEBHOOK_URL =
  "https://script.google.com/macros/s/AKfycbx8E_qzuTfpg3vxIsf-L9TqxAdwYgBUG_i2HqHtKNgwfaDgISXQu5yzdOWjVdUdwsJZ/exec";

type Row = {
  serial: number;
  name: string;
  village: string;
  phone: string;
};

type Payload =
  | {
      action: "add";
      serial: number;
      name: string;
      village: string;
      phone: string;
    }
  | {
      action: "delete";
      serial: number;
      phone: string;
    }
  | {
      action: "replace";
      rows: Row[];
    }
  | {
      action: "reset";
    };

function getWebhookUrl(): string {
  if (typeof window === "undefined") return "";
  try {
    const raw = localStorage.getItem("drum.settings.v1");
    if (raw) {
      const parsed = JSON.parse(raw) as { sheetWebhookUrl?: string };
      const url = (parsed.sheetWebhookUrl ?? "").trim();
      if (url) return url;
    }
  } catch {
    /* ignore */
  }
  return DEFAULT_WEBHOOK_URL;
}

function post(payload: Payload) {
  const url = getWebhookUrl();
  if (!url) return;
  try {
    // text/plain avoids CORS preflight for Apps Script webhooks.
    void fetch(url, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(payload),
      keepalive: true,
    }).catch((err) => {
      console.warn("[sheet-sync] failed", err);
    });
  } catch (err) {
    console.warn("[sheet-sync] failed", err);
  }
}

export function syncAddToSheet(row: {
  serial_number: number;
  customer_name: string;
  village: string | null;
  mobile_number: string | null;
}) {
  post({
    action: "add",
    serial: row.serial_number,
    name: row.customer_name ?? "",
    village: row.village ?? "",
    phone: row.mobile_number ?? "",
  });
}

export function syncDeleteToSheet(row: {
  serial_number: number;
  mobile_number: string | null;
}) {
  post({
    action: "delete",
    serial: row.serial_number,
    phone: row.mobile_number ?? "",
  });
}

// Send the full current list so the sheet mirrors DB exactly.
// Used after delete (resequence shifts serials) and any bulk change.
export function syncReplaceSheet(
  rows: Array<{
    serial_number: number;
    customer_name: string;
    village: string | null;
    mobile_number: string | null;
  }>,
) {
  post({
    action: "replace",
    rows: rows.map((r) => ({
      serial: r.serial_number,
      name: r.customer_name ?? "",
      village: r.village ?? "",
      phone: r.mobile_number ?? "",
    })),
  });
}

export function syncResetSheet() {
  post({ action: "reset" });
}
