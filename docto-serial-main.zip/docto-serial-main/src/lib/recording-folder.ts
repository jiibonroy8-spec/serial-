// Browser-only helpers: remember the recordings folder and read new audio files.

const DB_NAME = "doctor-serial";
const STORE = "handles";
const HANDLE_KEY = "recordings-dir";
const SEEN_KEY = "recordings.seen.v1";

type DirHandle = FileSystemDirectoryHandle;

export function supportsFolderPicker() {
  return typeof window !== "undefined" && "showDirectoryPicker" in window;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbSet(key: string, value: unknown) {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

async function idbGet<T>(key: string): Promise<T | null> {
  const db = await openDb();
  const value = await new Promise<T | null>((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).get(key);
    req.onsuccess = () => resolve((req.result as T) ?? null);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return value;
}

export async function pickRecordingsFolder(): Promise<DirHandle | null> {
  if (!supportsFolderPicker()) return null;
  const picker = (window as unknown as {
    showDirectoryPicker: (o?: { mode?: string }) => Promise<DirHandle>;
  }).showDirectoryPicker;
  const handle = await picker({ mode: "read" });
  await idbSet(HANDLE_KEY, handle);
  return handle;
}

export async function getSavedFolder(): Promise<DirHandle | null> {
  try {
    const handle = await idbGet<DirHandle>(HANDLE_KEY);
    if (!handle) return null;
    const query = (handle as unknown as {
      queryPermission?: (o: { mode: string }) => Promise<PermissionState>;
    }).queryPermission;
    if (query) {
      const state = await query.call(handle, { mode: "read" });
      if (state !== "granted") return handle; // caller may request permission
    }
    return handle;
  } catch {
    return null;
  }
}

export async function ensureFolderPermission(handle: DirHandle): Promise<boolean> {
  const h = handle as unknown as {
    queryPermission?: (o: { mode: string }) => Promise<PermissionState>;
    requestPermission?: (o: { mode: string }) => Promise<PermissionState>;
  };
  if (!h.queryPermission) return true;
  let state = await h.queryPermission({ mode: "read" });
  if (state !== "granted" && h.requestPermission) {
    state = await h.requestPermission({ mode: "read" });
  }
  return state === "granted";
}

const AUDIO_RE = /\.(m4a|mp4|aac|mp3|wav|caf)$/i;

function readSeen(): Set<string> {
  try {
    return new Set(JSON.parse(localStorage.getItem(SEEN_KEY) ?? "[]") as string[]);
  } catch {
    return new Set();
  }
}

export function markSeen(keys: string[]) {
  const seen = readSeen();
  keys.forEach((k) => seen.add(k));
  localStorage.setItem(SEEN_KEY, JSON.stringify(Array.from(seen).slice(-2000)));
}

/** Files in the chosen folder that were not handled before. */
export async function listNewRecordings(handle: DirHandle): Promise<File[]> {
  const seen = readSeen();
  const out: File[] = [];
  const entries = (handle as unknown as {
    values: () => AsyncIterable<FileSystemHandle>;
  }).values();
  for await (const entry of entries) {
    if (entry.kind !== "file" || !AUDIO_RE.test(entry.name)) continue;
    const file = await (entry as FileSystemFileHandle).getFile();
    const key = `${file.name}:${file.size}:${file.lastModified}`;
    if (seen.has(key)) continue;
    out.push(file);
  }
  return out.sort((a, b) => a.lastModified - b.lastModified);
}

export function fileKey(file: File) {
  return `${file.name}:${file.size}:${file.lastModified}`;
}

export async function fileToBase64(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}
