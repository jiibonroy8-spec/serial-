import { createServerFn } from "@tanstack/react-start";
import {
  cleanSuggestionValue,
  parseSuggestionKind,
  type SuggestionRow,
} from "@/lib/serial-suggestions.utils";

export const listSerialSuggestions = createServerFn({ method: "GET" })
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("serial_suggestions")
      .select("id, kind, value, created_at, updated_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []) as SuggestionRow[];
  });

export const rememberSerialSuggestion = createServerFn({ method: "POST" })
  .inputValidator((data: { kind: unknown; value: unknown }) => ({
    kind: parseSuggestionKind(data?.kind),
    value: cleanSuggestionValue(data?.value),
  }))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existing, error: existingError } = await supabaseAdmin
      .from("serial_suggestions")
      .select("id, kind, value, created_at, updated_at")
      .eq("kind", data.kind)
      .ilike("value", data.value)
      .maybeSingle();
    if (existingError) throw new Error(existingError.message);
    if (existing) return existing as SuggestionRow;

    const { data: inserted, error } = await supabaseAdmin
      .from("serial_suggestions")
      .insert({ kind: data.kind, value: data.value })
      .select("id, kind, value, created_at, updated_at")
      .single();
    if (error) {
      if (error.code === "23505") {
        const { data: duplicated, error: duplicatedError } = await supabaseAdmin
          .from("serial_suggestions")
          .select("id, kind, value, created_at, updated_at")
          .eq("kind", data.kind)
          .ilike("value", data.value)
          .single();
        if (duplicatedError) throw new Error(duplicatedError.message);
        return duplicated as SuggestionRow;
      }
      throw new Error(error.message);
    }
    return inserted as SuggestionRow;
  });

export const replaceSerialSuggestions = createServerFn({ method: "POST" })
  .inputValidator((data: { kind: unknown; values: unknown }) => {
    const kind = parseSuggestionKind(data?.kind);
    if (!Array.isArray(data?.values)) throw new Error("Invalid suggestions");
    const seen = new Set<string>();
    const values: string[] = [];
    for (const value of data.values) {
      if (typeof value !== "string") continue;
      const cleaned = value.trim();
      if (!cleaned) continue;
      const key = cleaned.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      values.push(cleaned);
    }
    return { kind, values };
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: deleteError } = await supabaseAdmin
      .from("serial_suggestions")
      .delete()
      .eq("kind", data.kind);
    if (deleteError) throw new Error(deleteError.message);

    if (data.values.length > 0) {
      const { error: insertError } = await supabaseAdmin
        .from("serial_suggestions")
        .insert(data.values.map((value) => ({ kind: data.kind, value })));
      if (insertError) throw new Error(insertError.message);
    }

    const { data: rows, error } = await supabaseAdmin
      .from("serial_suggestions")
      .select("id, kind, value, created_at, updated_at")
      .eq("kind", data.kind)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (rows ?? []) as SuggestionRow[];
  });