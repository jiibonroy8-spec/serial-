// Server-only helpers for the call-recording → serial pipeline.

export const MAX_RECORDING_BYTES = 50 * 1024 * 1024;

export const ALLOWED_RECORDING_TYPES = new Set([
  "audio/m4a",
  "audio/x-m4a",
  "audio/mp4",
  "audio/aac",
  "audio/mpeg",
  "audio/wav",
  "audio/x-wav",
  "application/octet-stream",
]);
export const ALLOWED_RECORDING_EXTENSIONS = ["m4a", "mp4", "aac", "mp3", "wav", "caf"];

export function safeExtension(filename: string): string {
  const parts = filename.toLowerCase().split(".");
  return parts.length > 1 ? parts[parts.length - 1]!.replace(/[^a-z0-9]/g, "") : "";
}

export function sanitizeFilename(filename: string): string {
  const base = filename.split(/[\\/]/).pop() ?? "recording.m4a";
  return base.replace(/[^\w.\- ()\u0980-\u09FF]/g, "_").slice(0, 180) || "recording.m4a";
}

export async function sha256Hex(buffer: ArrayBuffer): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export type StoreResult =
  | { ok: true; duplicate: boolean; recordingId: string }
  | { ok: false; status: number; error: string };

export async function storeRecording(args: {
  bytes: ArrayBuffer;
  filename: string;
  fileType: string;
  recordedAt?: string | null;
  duration?: number | null;
}): Promise<StoreResult> {
  const originalFilename = sanitizeFilename(args.filename || "recording.m4a");
  const extension = safeExtension(originalFilename) || "m4a";
  const fileType = args.fileType || "audio/m4a";

  if (!ALLOWED_RECORDING_EXTENSIONS.includes(extension)) {
    return { ok: false, status: 415, error: "unsupported_file_type" };
  }
  if (args.bytes.byteLength <= 0) return { ok: false, status: 400, error: "empty_file" };
  if (args.bytes.byteLength > MAX_RECORDING_BYTES) {
    return { ok: false, status: 413, error: "file_too_large" };
  }

  const checksum = await sha256Hex(args.bytes);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: existing, error: lookupError } = await supabaseAdmin
    .from("call_recordings")
    .select("id")
    .eq("checksum", checksum)
    .maybeSingle();
  if (lookupError) {
    console.error(`[call-recordings] lookup failed: ${lookupError.message}`);
    return { ok: false, status: 500, error: "storage_error" };
  }
  if (existing) return { ok: true, duplicate: true, recordingId: existing.id };

  const storagePath = `${new Date().toISOString().slice(0, 10)}/${checksum}.${extension}`;
  const { error: uploadError } = await supabaseAdmin.storage
    .from("call-recordings")
    .upload(storagePath, args.bytes, {
      contentType: fileType === "application/octet-stream" ? "audio/mp4" : fileType,
      upsert: true,
    });
  if (uploadError) {
    console.error(`[call-recordings] storage upload failed: ${uploadError.message}`);
    return { ok: false, status: 500, error: "upload_failed" };
  }

  const { data: inserted, error: insertError } = await supabaseAdmin
    .from("call_recordings")
    .insert({
      original_filename: originalFilename,
      storage_path: storagePath,
      file_type: fileType,
      file_size: args.bytes.byteLength,
      duration_seconds: args.duration ?? null,
      checksum,
      recorded_at: args.recordedAt ?? null,
      processing_status: "uploaded",
    })
    .select("id")
    .single();

  if (insertError) {
    if (insertError.code === "23505") {
      const { data: race } = await supabaseAdmin
        .from("call_recordings")
        .select("id")
        .eq("checksum", checksum)
        .maybeSingle();
      if (race) return { ok: true, duplicate: true, recordingId: race.id };
    }
    console.error(`[call-recordings] insert failed: ${insertError.message}`);
    return { ok: false, status: 500, error: "record_failed" };
  }

  return { ok: true, duplicate: false, recordingId: inserted.id };
}

// ---------------- AI: transcription + extraction ----------------

const GATEWAY = "https://ai.gateway.lovable.dev/v1";

function apiKey() {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  return key;
}

export async function transcribeBengali(
  bytes: ArrayBuffer,
  filename: string,
  contentType: string,
): Promise<string> {
  const form = new FormData();
  form.append("model", "google/gemini-3.5-transcribe");
  form.append(
    "file",
    new Blob([bytes], { type: contentType === "application/octet-stream" ? "audio/mp4" : contentType }),
    filename,
  );
  form.append("language", "bn");
  form.append("stream", "true");

  const res = await fetch(`${GATEWAY}/audio/transcriptions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey()}` },
    body: form,
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`transcription_failed_${res.status}: ${detail.slice(0, 300)}`);
  }

  const raw = await res.text();
  let text = "";
  for (const line of raw.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("data:")) continue;
    const payload = trimmed.slice(5).trim();
    if (!payload || payload === "[DONE]") continue;
    try {
      const evt = JSON.parse(payload) as { type?: string; delta?: string; text?: string };
      if (evt.type === "transcript.text.delta" && evt.delta) text += evt.delta;
      else if (evt.type === "transcript.text.done" && evt.text) text = evt.text;
    } catch {
      /* ignore malformed keepalive lines */
    }
  }
  return text.trim();
}

export type Extracted = { name: string | null; village: string | null; mobile: string | null };

export async function extractPatientDetails(transcript: string): Promise<Extracted> {
  const res = await fetch(`${GATEWAY}/responses`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey(),
      "X-Lovable-AIG-SDK": "fetch",
    },
    body: JSON.stringify({
      model: "openai/gpt-6-astra",
      stream: true,
      reasoning: { effort: "low" },
      input: [
        {
          role: "system",
          content: [
            {
              type: "input_text",
              text:
                "You extract patient booking details from a Bengali phone-call transcript of a doctor's chamber. " +
                "Return the patient name in Bengali script, the village/area name in Bengali script, and the Bangladeshi mobile number as digits only " +
                "(normalised to 11 digits starting with 01). Use null for anything not clearly stated. Never invent values.",
            },
          ],
        },
        { role: "user", content: [{ type: "input_text", text: transcript }] },
      ],
      text: {
        format: {
          type: "json_schema",
          name: "patient_details",
          strict: true,
          schema: {
            type: "object",
            additionalProperties: false,
            properties: {
              name: { type: ["string", "null"] },
              village: { type: ["string", "null"] },
              mobile: { type: ["string", "null"] },
            },
            required: ["name", "village", "mobile"],
          },
        },
      },
    }),
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`extraction_failed_${res.status}: ${detail.slice(0, 300)}`);
  }

  const raw = await res.text();
  let out = "";
  for (const line of raw.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("data:")) continue;
    const payload = trimmed.slice(5).trim();
    if (!payload || payload === "[DONE]") continue;
    try {
      const evt = JSON.parse(payload) as {
        type?: string;
        delta?: string;
        response?: { output_text?: string };
      };
      if (evt.type === "response.output_text.delta" && evt.delta) out += evt.delta;
      else if (evt.type === "response.completed" && evt.response?.output_text) {
        out = evt.response.output_text;
      }
    } catch {
      /* ignore */
    }
  }

  try {
    const parsed = JSON.parse(out) as Extracted;
    return {
      name: normaliseText(parsed.name),
      village: normaliseText(parsed.village),
      mobile: normaliseMobile(parsed.mobile),
    };
  } catch {
    return { name: null, village: null, mobile: null };
  }
}

function normaliseText(value: string | null | undefined) {
  const v = (value ?? "").trim();
  return v ? v.replace(/\s+/g, " ") : null;
}

export function normaliseMobile(value: string | null | undefined) {
  if (!value) return null;
  let digits = value
    .replace(/[০-৯]/g, (d) => String("০১২৩৪৫৬৭৮৯".indexOf(d)))
    .replace(/\D/g, "");
  if (digits.startsWith("880")) digits = digits.slice(3);
  if (digits.length === 10 && digits.startsWith("1")) digits = `0${digits}`;
  return digits.length === 11 && digits.startsWith("01") ? digits : null;
}

/**
 * Call recordings are saved with the caller's number in the filename, which is far
 * more reliable than a number heard in the audio. Pull the first BD mobile number
 * out of the filename.
 */
export function mobileFromFilename(filename: string | null | undefined) {
  if (!filename) return null;
  const base = filename
    .split(/[\\/]/)
    .pop()!
    .replace(/\.[a-z0-9]+$/i, "")
    .replace(/[০-৯]/g, (d) => String("০১২৩৪৫৬৭৮৯".indexOf(d)));

  for (const match of base.matchAll(/\d[\d\s\-().]{8,}\d/g)) {
    const digits = match[0].replace(/\D/g, "");
    // Scan every window so numbers glued to dates/prefixes still resolve.
    for (let i = 0; i + 11 <= digits.length; i += 1) {
      const candidate = normaliseMobile(digits.slice(i, i + 11));
      if (candidate) return candidate;
    }
    const whole = normaliseMobile(digits);
    if (whole) return whole;
  }
  return null;
}
