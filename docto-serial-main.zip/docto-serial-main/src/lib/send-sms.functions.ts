import { createServerFn } from "@tanstack/react-start";

export const sendBulkSmsMany = createServerFn({ method: "POST" })
  .inputValidator((data: { numbers: string[]; message: string }) => {
    if (!data || !Array.isArray(data.numbers) || typeof data.message !== "string") {
      throw new Error("Invalid input");
    }
    const msg = data.message.trim();
    if (!msg) throw new Error("Message empty");
    const cleaned = Array.from(
      new Set(
        data.numbers
          .map((n) => (typeof n === "string" ? n.replace(/\D/g, "") : ""))
          .filter((n) => n.length === 11),
      ),
    );
    if (cleaned.length === 0) throw new Error("No valid numbers");
    return { numbers: cleaned, message: msg };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.BULKSMSBD_API_KEY;
    const senderId = process.env.BULKSMSBD_SENDER_ID;
    if (!apiKey || !senderId) {
      return { ok: false, sent: 0, failed: data.numbers.length, error: "SMS credentials not configured" };
    }

    // BulkSMSBD supports comma-separated numbers in a single call
    const url = "http://bulksmsbd.net/api/smsapi";
    const params = new URLSearchParams({
      api_key: apiKey,
      type: "text",
      number: data.numbers.join(","),
      senderid: senderId,
      message: data.message,
    });

    try {
      const res = await fetch(`${url}?${params.toString()}`, { method: "GET" });
      const text = await res.text();
      let code: number | null = null;
      try {
        const j = JSON.parse(text) as { response_code?: number };
        if (typeof j.response_code === "number") code = j.response_code;
      } catch {
        /* not json */
      }
      const ok = code === 202;
      return {
        ok,
        code,
        sent: ok ? data.numbers.length : 0,
        failed: ok ? 0 : data.numbers.length,
        raw: text.slice(0, 500),
      };
    } catch (e) {
      return {
        ok: false,
        sent: 0,
        failed: data.numbers.length,
        error: e instanceof Error ? e.message : "Network error",
      };
    }
  });

export const sendBulkSms = createServerFn({ method: "POST" })
  .inputValidator((data: { number: string; message: string }) => {
    if (!data || typeof data.number !== "string" || typeof data.message !== "string") {
      throw new Error("Invalid input");
    }
    const digits = data.number.replace(/\D/g, "");
    if (digits.length !== 11) throw new Error("Number must be 11 digits");
    if (!data.message.trim()) throw new Error("Message empty");
    return { number: digits, message: data.message };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.BULKSMSBD_API_KEY;
    const senderId = process.env.BULKSMSBD_SENDER_ID;
    if (!apiKey || !senderId) {
      return { ok: false, error: "SMS credentials not configured" };
    }

    const url = "http://bulksmsbd.net/api/smsapi";
    const params = new URLSearchParams({
      api_key: apiKey,
      type: "text",
      number: data.number,
      senderid: senderId,
      message: data.message,
    });

    try {
      const res = await fetch(`${url}?${params.toString()}`, { method: "GET" });
      const text = await res.text();
      let code: number | null = null;
      try {
        const j = JSON.parse(text) as { response_code?: number };
        if (typeof j.response_code === "number") code = j.response_code;
      } catch {
        /* not json */
      }
      const ok = code === 202;
      return { ok, code, raw: text.slice(0, 500) };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : "Network error" };
    }
  });
