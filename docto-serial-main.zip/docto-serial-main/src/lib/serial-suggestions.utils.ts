export type SuggestionKind = "name" | "village" | "mobile";

export type SuggestionRow = {
  id: string;
  kind: SuggestionKind;
  value: string;
  created_at: string;
  updated_at: string;
};

export function parseSuggestionKind(value: unknown): SuggestionKind {
  if (value === "name" || value === "village" || value === "mobile") return value;
  throw new Error("Invalid suggestion type");
}

export function cleanSuggestionValue(value: unknown): string {
  if (typeof value !== "string") throw new Error("Invalid suggestion value");
  const cleaned = value.trim();
  if (!cleaned) throw new Error("Suggestion value required");
  return cleaned;
}
