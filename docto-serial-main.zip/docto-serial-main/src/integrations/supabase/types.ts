export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      call_recordings: {
        Row: {
          checksum: string
          created_at: string
          drum_id: string | null
          duration_seconds: number | null
          error_message: string | null
          extracted_mobile: string | null
          extracted_name: string | null
          extracted_village: string | null
          file_size: number
          file_type: string
          id: string
          original_filename: string
          processing_status: string
          recorded_at: string | null
          review_note: string | null
          storage_path: string
          transcript: string | null
          updated_at: string
        }
        Insert: {
          checksum: string
          created_at?: string
          drum_id?: string | null
          duration_seconds?: number | null
          error_message?: string | null
          extracted_mobile?: string | null
          extracted_name?: string | null
          extracted_village?: string | null
          file_size: number
          file_type: string
          id?: string
          original_filename: string
          processing_status?: string
          recorded_at?: string | null
          review_note?: string | null
          storage_path: string
          transcript?: string | null
          updated_at?: string
        }
        Update: {
          checksum?: string
          created_at?: string
          drum_id?: string | null
          duration_seconds?: number | null
          error_message?: string | null
          extracted_mobile?: string | null
          extracted_name?: string | null
          extracted_village?: string | null
          file_size?: number
          file_type?: string
          id?: string
          original_filename?: string
          processing_status?: string
          recorded_at?: string | null
          review_note?: string | null
          storage_path?: string
          transcript?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "call_recordings_drum_id_fkey"
            columns: ["drum_id"]
            isOneToOne: false
            referencedRelation: "drums"
            referencedColumns: ["id"]
          },
        ]
      }
      drums: {
        Row: {
          call_recording_id: string | null
          created_at: string
          customer_name: string
          drum_number: string | null
          id: string
          mobile_number: string | null
          serial_number: number
          sms_sent: boolean
          source: string
          village: string | null
        }
        Insert: {
          call_recording_id?: string | null
          created_at?: string
          customer_name: string
          drum_number?: string | null
          id?: string
          mobile_number?: string | null
          serial_number?: number
          sms_sent?: boolean
          source?: string
          village?: string | null
        }
        Update: {
          call_recording_id?: string | null
          created_at?: string
          customer_name?: string
          drum_number?: string | null
          id?: string
          mobile_number?: string | null
          serial_number?: number
          sms_sent?: boolean
          source?: string
          village?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "drums_call_recording_id_fkey"
            columns: ["call_recording_id"]
            isOneToOne: false
            referencedRelation: "call_recordings"
            referencedColumns: ["id"]
          },
        ]
      }
      serial_suggestions: {
        Row: {
          created_at: string
          id: string
          kind: string
          updated_at: string
          value: string
        }
        Insert: {
          created_at?: string
          id?: string
          kind: string
          updated_at?: string
          value: string
        }
        Update: {
          created_at?: string
          id?: string
          kind?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_drum_serial: {
        Args: {
          _call_recording_id?: string
          _customer_name: string
          _drum_number?: string
          _mobile_number?: string
          _source?: string
          _village?: string
        }
        Returns: {
          call_recording_id: string | null
          created_at: string
          customer_name: string
          drum_number: string | null
          id: string
          mobile_number: string | null
          serial_number: number
          sms_sent: boolean
          source: string
          village: string | null
        }
        SetofOptions: {
          from: "*"
          to: "drums"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      delete_and_resequence: { Args: { _id: string }; Returns: undefined }
      remember_serial_suggestion: {
        Args: { _kind: string; _value: string }
        Returns: {
          created_at: string
          id: string
          kind: string
          updated_at: string
          value: string
        }
        SetofOptions: {
          from: "*"
          to: "serial_suggestions"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      reset_drums: { Args: never; Returns: undefined }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
