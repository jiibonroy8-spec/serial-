import { createFileRoute } from "@tanstack/react-router";

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const ALLOWED_TYPES = new Set([
  "audio/m4a",
  "audio/x-m4a",
  "audio/mp4",
  "audio/aac",
  "audio/mpeg",
  "audio/wav",
  "audio/x-wav",
  "application/octet-stream", // iOS Shortcuts sometimes omits a proper type
]);
const ALLOWED_EXTENSIONS = ["m4a", "mp4", "aac", "mp3", "wav", "caf"];

function json(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function safeExtension(filename: string): string {
  const parts = filename.toLowerCase().split(".");
  const ext = parts.length > 1 ? parts[parts.length - 1]!.replace(/[^a-z0-9]/g, "") : "";
  return ext;
}

function sanitizeFilename(filename: string): string {
  const base = filename.split(/[\\/]/).pop() ?? "recording.m4a";
  return base.replace(/[^\w.\- ()\u0980-\u09FF]/g, "_").slice(0, 180) || "recording.m4a";
}

async function sha256Hex(buffer: ArrayBuffer): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export const Route = createFileRoute("/api/public/call-recordings/upload")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const expectedToken = process.env["CALL_RECORDING_UPLOAD_TOKEN"];
        if (!expectedToken) {
          console.error("[call-recordings] upload token is not configured");
          return json({ error: "server_not_configured" }, 500);
        }

        const authHeader = request.headers.get("authorization") ?? "";
        const provided = authHeader.startsWith("Bearer ")
          ? authHeader.slice(7)
          : (request.headers.get("x-upload-token") ?? "");

        // constant-time-ish comparison
        if (
          provided.length !== expectedToken.length ||
          !provided.split("").every((c, i) => c === expectedToken[i])
        ) {
          console.warn("[call-recordings] rejected upload: invalid token");
          return json({ error: "unauthorized" }, 401);
        }

        let form: FormData;
        try {
          form = await request.formData();
        } catch {
          return json({ error: "invalid_form_data" }, 400);
        }

        const file = form.get("file");
        if (!(file instanceof File)) {
          return json({ error: "missing_file" }, 400);
        }

        const originalFilename = sanitizeFilename(
          (form.get("original_filename") as string | null)?.trim() || file.name || "recording.m4a",
        );
        const extension = safeExtension(originalFilename) || safeExtension(file.name) || "m4a";
        const fileType = file.type || "audio/m4a";

        if (!ALLOWED_EXTENSIONS.includes(extension) || !ALLOWED_TYPES.has(fileType)) {
          console.warn(
            `[call-recordings] rejected upload: unsupported type ext=${extension} mime=${fileType}`,
          );
          return json({ error: "unsupported_file_type", extension, fileType }, 415);
        }

        if (file.size <= 0) return json({ error: "empty_file" }, 400);
        if (file.size > MAX_FILE_SIZE) {
          console.warn(`[call-recordings] rejected upload: too large size=${file.size}`);
          return json({ error: "file_too_large", maxBytes: MAX_FILE_SIZE }, 413);
        }

        const bytes = await file.arrayBuffer();
        const checksum = await sha256Hex(bytes);

        const rawCreatedAt = (form.get("created_at") as string | null)?.trim();
        let recordedAt: string | null = null;
        if (rawCreatedAt) {
          const parsed = new Date(rawCreatedAt);
          if (!Number.isNaN(parsed.getTime())) recordedAt = parsed.toISOString();
        }

        const rawDuration = (form.get("duration") as string | null)?.trim();
        const duration = rawDuration && !Number.isNaN(Number(rawDuration)) ? Number(rawDuration) : null;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Duplicate protection by content checksum.
        const { data: existing, error: lookupError } = await supabaseAdmin
          .from("call_recordings")
          .select("id, processing_status, created_at")
          .eq("checksum", checksum)
          .maybeSingle();

        if (lookupError) {
          console.error(`[call-recordings] lookup failed: ${lookupError.message}`);
          return json({ error: "storage_error" }, 500);
        }

        if (existing) {
          console.info(`[call-recordings] duplicate upload ignored id=${existing.id}`);
          return json({ duplicate: true, recording: existing }, 200);
        }

        const storagePath = `${new Date().toISOString().slice(0, 10)}/${checksum}.${extension}`;

        const { error: uploadError } = await supabaseAdmin.storage
          .from("call-recordings")
          .upload(storagePath, bytes, {
            contentType: fileType === "application/octet-stream" ? "audio/mp4" : fileType,
            upsert: true,
          });

        if (uploadError) {
          console.error(`[call-recordings] storage upload failed: ${uploadError.message}`);
          return json({ error: "upload_failed" }, 500);
        }

        const { data: inserted, error: insertError } = await supabaseAdmin
          .from("call_recordings")
          .insert({
            original_filename: originalFilename,
            storage_path: storagePath,
            file_type: fileType,
            file_size: file.size,
            duration_seconds: duration,
            checksum,
            recorded_at: recordedAt,
            processing_status: "uploaded",
          })
          .select("id, original_filename, storage_path, file_type, file_size, duration_seconds, recorded_at, processing_status, created_at")
          .single();

        if (insertError) {
          // Unique violation => a concurrent request already stored this file.
          if (insertError.code === "23505") {
            const { data: race } = await supabaseAdmin
              .from("call_recordings")
              .select("id, processing_status, created_at")
              .eq("checksum", checksum)
              .maybeSingle();
            console.info("[call-recordings] concurrent duplicate resolved");
            return json({ duplicate: true, recording: race }, 200);
          }
          console.error(`[call-recordings] insert failed: ${insertError.message}`);
          return json({ error: "record_failed" }, 500);
        }

        console.info(
          `[call-recordings] stored id=${inserted.id} size=${file.size} type=${fileType}`,
        );
        return json({ duplicate: false, recording: inserted }, 201);
      },
    },
  },
});
