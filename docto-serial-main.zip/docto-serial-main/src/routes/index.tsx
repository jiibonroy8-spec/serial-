import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast, Toaster } from "sonner";
import { Loader2, Plus, User, MapPin, Phone } from "lucide-react";
import { useDrums } from "@/hooks/use-drums";

import { useSettings } from "@/hooks/use-settings";

import { SettingsButton } from "@/components/settings-sheet";
import { renderSms } from "@/lib/sms";
import { sendBulkSms } from "@/lib/send-sms.functions";
import { bnToEnDigits } from "@/lib/utils";



export const Route = createFileRoute("/")({
  beforeLoad: () => {
    if (typeof window !== "undefined") {
      sessionStorage.setItem("drum.session.visited", "1");
    }
  },
  head: () => ({
    meta: [
      { title: "Entry — Doctor Serial" },
      { name: "description", content: "Create a new patient serial entry." },
    ],
  }),
  component: Index,
});

function Index() {
  const { drums, addDrum, markSmsSent } = useDrums();
  const {
    settings,
    save,
    rememberName,
    rememberVillage,
    rememberMobile,
    replaceSavedNames,
    replaceSavedVillages,
    replaceSavedMobiles,
  } = useSettings();

  const [name, setName] = useState("");
  const [village, setVillage] = useState("");
  const [mobileRest, setMobileRest] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [nameFocus, setNameFocus] = useState(false);
  const [villageFocus, setVillageFocus] = useState(false);
  const [mobileFocus, setMobileFocus] = useState(false);

  const nameRef = useRef<HTMLInputElement>(null);
  const villageRef = useRef<HTMLInputElement>(null);
  const mobileRef = useRef<HTMLInputElement>(null);


  const totalCount = drums.length;
  const nextSerial = (drums[0]?.serial_number ?? 0) + 1;

  const [todayLabel, setTodayLabel] = useState("");
  useEffect(() => {
    setTodayLabel(
      new Date().toLocaleDateString(undefined, {
        weekday: "long",
        month: "long",
        day: "numeric",
      }),
    );
  }, []);

  const nameSuggestions = useMemo(
    () => filterSuggestions(settings.savedNames, name),
    [settings.savedNames, name],
  );
  const villageSuggestions = useMemo(
    () => filterSuggestions(settings.savedVillages, village),
    [settings.savedVillages, village],
  );
  const mobileSuggestions = useMemo(() => {
    const list = settings.savedMobiles ?? [];
    const typed = mobileRest.replace(/\D/g, "");
    if (!typed) return [];
    const full = "01" + typed;
    return list.filter((m) => m.startsWith(full) && m !== full).slice(0, 8);
  }, [settings.savedMobiles, mobileRest]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const n = name.trim();
    const v = village.trim();
    const digits = mobileRest.replace(/\D/g, "").slice(0, 9);
    const fullMobile = digits ? "01" + digits : "";

    if (!n) {
      toast.error("নাম দিন");
      return;
    }
    if (fullMobile && fullMobile.length !== 11) {
      toast.error("মোবাইল নাম্বার ১১ ডিজিট হতে হবে");
      return;
    }

    setSubmitting(true);
    const row = await addDrum({
      customer_name: n,
      village: v || null,
      mobile_number: fullMobile || null,
    });
    setSubmitting(false);
    if (!row) return;

    rememberName(n);
    if (v) rememberVillage(v);
    if (fullMobile) rememberMobile(fullMobile);

    setName("");
    setVillage("");
    setMobileRest("");

    const { message, info } = renderSms(settings.smsTemplate, row, [...drums, row]);
    toast.success(
      `সিরিয়াল #${String(row.serial_number).padStart(3, "0")} সংরক্ষিত — চেম্বার সিরিয়াল ${info.serial} (${info.chamberDayLabel})`,
    );
    if (settings.bulkSmsEnabled && row.mobile_number) {
      try {
        const res = await sendBulkSms({ data: { number: row.mobile_number, message } });
        if (res.ok) {
          markSmsSent(row.id, true);
          toast.success("SMS পাঠানো হয়েছে");
        } else {
          toast.error(`SMS পাঠানো যায়নি${res.code ? ` (কোড ${res.code})` : ""}`);
        }
      } catch {
        toast.error("SMS পাঠানো যায়নি");
      }
    }
    nameRef.current?.focus();
  }



  return (
    <div className="min-h-dvh">

      <Toaster position="top-center" richColors />
      <div className="mx-auto max-w-xl px-4 pb-28 pt-6">
        <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 pb-5">
          <div className="min-w-0">
            <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-muted-foreground">
              {settings.tagline}
            </p>
            <h1 className="font-display truncate text-3xl font-semibold leading-tight text-foreground">
              {settings.brandName}
            </h1>
          </div>
          <SettingsButton
            settings={settings}
            save={save}
            replaceSavedNames={replaceSavedNames}
            replaceSavedVillages={replaceSavedVillages}
            replaceSavedMobiles={replaceSavedMobiles}
          />
        </header>

        <div className="hairline-gold h-px w-full opacity-70" />

        <section className="card-premium mt-5 overflow-hidden">
          <div className="flex items-stretch">
            <div className="flex flex-col items-center justify-center gap-1 border-r border-border bg-[color-mix(in_oklab,var(--primary)_6%,transparent)] px-6 py-6">
              <span className="text-[10px] font-semibold uppercase tracking-[0.22em] text-muted-foreground">
                মোট
              </span>
              <span className="num-premium text-6xl font-bold leading-none text-foreground">
                {totalCount}
              </span>
              <span className="text-[11px] text-muted-foreground">সিরিয়াল</span>
            </div>
            <div className="flex flex-1 flex-col justify-center px-5 py-4">
              <span className="text-[10px] font-semibold uppercase tracking-[0.22em] text-muted-foreground">
                পরবর্তী সিরিয়াল
              </span>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="num-premium text-5xl font-bold text-primary">
                  #{String(nextSerial).padStart(3, "0")}
                </span>
              </div>
              <span className="mt-1 text-xs text-muted-foreground" suppressHydrationWarning>
                {todayLabel || "\u00a0"}
              </span>
            </div>
          </div>
        </section>

        <form onSubmit={submit} className="card-premium mt-4 space-y-3 p-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">নতুন এন্ট্রি</h2>
            <span className="num-premium text-xl font-bold text-foreground">
              #{String(nextSerial).padStart(3, "0")}
            </span>
          </div>

          <Field icon={<User className="h-4 w-4" />} label="নাম">
            <div className="relative">
              <input
                ref={nameRef}
                type="text"
                autoCapitalize="words"
                autoComplete="off"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onFocus={() => setNameFocus(true)}
                onBlur={() => setTimeout(() => setNameFocus(false), 150)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    villageRef.current?.focus();
                  }
                }}
                placeholder="রোগীর নাম"
                className="input-premium"
              />
              {nameFocus && nameSuggestions.length > 0 && (
                <SuggestionDropdown
                  items={nameSuggestions}
                  onPick={(v) => {
                    setName(v);
                    setNameFocus(false);
                    villageRef.current?.focus();
                  }}
                />
              )}
            </div>
          </Field>

          <Field icon={<MapPin className="h-4 w-4" />} label="গ্রাম (ঐচ্ছিক)">
            <div className="relative">
              <input
                ref={villageRef}
                type="text"
                autoComplete="off"
                value={village}
                onChange={(e) => setVillage(e.target.value)}
                onFocus={() => setVillageFocus(true)}
                onBlur={() => setTimeout(() => setVillageFocus(false), 150)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    mobileRef.current?.focus();
                  }
                }}
                placeholder="গ্রামের নাম"
                className="input-premium"
              />
              {villageFocus && villageSuggestions.length > 0 && (
                <SuggestionDropdown
                  items={villageSuggestions}
                  onPick={(v) => {
                    setVillage(v);
                    setVillageFocus(false);
                    mobileRef.current?.focus();
                  }}
                />
              )}
            </div>
          </Field>

          <Field icon={<Phone className="h-4 w-4" />} label="মোবাইল নাম্বার (ঐচ্ছিক)">
            <div className="relative">
              <div className="flex items-stretch overflow-hidden rounded-xl border border-input bg-background focus-within:ring-2 focus-within:ring-ring/40">
                <span className="grid select-none place-items-center border-r border-border bg-secondary px-3 font-mono text-sm font-semibold tabular text-secondary-foreground">
                  01
                </span>
                <input
                  ref={mobileRef}
                  type="tel"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={9}
                  value={mobileRest}
                  onChange={(e) => setMobileRest(bnToEnDigits(e.target.value).replace(/\D/g, "").slice(0, 9))}
                  onFocus={() => setMobileFocus(true)}
                  onBlur={() => setTimeout(() => setMobileFocus(false), 150)}
                  placeholder="XXXXXXXXX"
                  className="w-full bg-transparent px-3 py-3 text-base tabular outline-none"
                />
              </div>
              {mobileFocus && mobileSuggestions.length > 0 && (
                <SuggestionDropdown
                  items={mobileSuggestions}
                  onPick={(v) => {
                    setMobileRest(v.replace(/^0?1?/, "").slice(0, 9));
                    setMobileFocus(false);
                  }}
                />
              )}
            </div>
          </Field>

          <button
            type="submit"
            disabled={submitting}
            className="btn-premium mt-2 flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3.5 text-base font-semibold tracking-wide disabled:opacity-60"
          >
            {submitting ? <Loader2 className="h-5 w-5 animate-spin" /> : <Plus className="h-5 w-5" />}
            {submitting ? "সংরক্ষণ হচ্ছে…" : "সিরিয়াল সংরক্ষণ করুন"}
          </button>
        </form>
      </div>
      
    </div>
  );
}





function filterSuggestions(all: string[], q: string): string[] {
  const query = q.trim().toLowerCase();
  if (!query) return [];
  const starts: string[] = [];
  const contains: string[] = [];
  for (const v of all) {
    const lv = v.toLowerCase();
    if (lv === query) continue;
    if (lv.startsWith(query)) starts.push(v);
    else if (lv.includes(query)) contains.push(v);
  }
  return [...starts, ...contains].slice(0, 8);
}

function SuggestionDropdown({
  items,
  onPick,
}: {
  items: string[];
  onPick: (v: string) => void;
}) {
  return (
    <div className="absolute left-0 right-0 top-full z-30 mt-1 max-h-56 overflow-y-auto overscroll-contain rounded-xl border border-border bg-card shadow-xl">
      {items.map((v) => (
        <button
          key={v}
          type="button"
          onMouseDown={(e) => {
            e.preventDefault();
            onPick(v);
          }}
          className="block w-full truncate px-3.5 py-2 text-left text-sm text-foreground hover:bg-secondary"
        >
          {v}
        </button>
      ))}
    </div>
  );
}

function Field({
  icon,
  label,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        <span className="text-primary">{icon}</span>
        {label}
      </label>
      {children}
    </div>
  );
}
