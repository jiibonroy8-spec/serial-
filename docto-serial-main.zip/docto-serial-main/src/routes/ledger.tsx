import { createFileRoute, redirect } from "@tanstack/react-router";
import { memo, useCallback, useMemo, useState } from "react";
import { toast, Toaster } from "sonner";
import {
  Loader2,
  MapPin,
  Phone,
  Search,
  Trash2,
  Pencil,
  FileDown,
  Printer,
  MoreVertical,
  X,
  Check,
  Send,
  BellRing,
  ChevronDown,
} from "lucide-react";
import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useDrums, reloadDrums, isToday, fmtTime, fmtDate, type Drum } from "@/hooks/use-drums";
import { useSettings } from "@/hooks/use-settings";
import { renderSms } from "@/lib/sms";
import { sendBulkSms } from "@/lib/send-sms.functions";
import { bnToEnDigits } from "@/lib/utils";


import { SettingsButton } from "@/components/settings-sheet";
import { CallRecordingPanel } from "@/components/call-recording-panel";

export const Route = createFileRoute("/ledger")({
  beforeLoad: () => {
    // Fresh browser session (tab reopen / cleared state) → always land on Entry.
    if (typeof window !== "undefined") {
      const KEY = "drum.session.visited";
      if (!sessionStorage.getItem(KEY)) {
        sessionStorage.setItem(KEY, "1");
        throw redirect({ to: "/" });
      }
    }
  },
  head: () => ({
    meta: [
      { title: "Ledger — Doctor Serial" },
      { name: "description", content: "Full drum serial ledger." },
    ],
  }),
  component: Ledger,
});

function Ledger() {
  const { drums, loading, updateDrum, deleteDrum, resetAll, markSmsSent } = useDrums();
  const { settings, save, rememberName, rememberVillage, rememberMobile, replaceSavedNames, replaceSavedVillages, replaceSavedMobiles } = useSettings();
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Drum | null>(null);
  const [resendingId, setResendingId] = useState<string | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Drum | null>(null);
  const [printRows, setPrintRows] = useState<Drum[] | null>(null);
  const [tab, setTab] = useState<"all" | "manual" | "auto">("all");

  useEffect(() => {
    if (!printRows) return;
    let cancelled = false;
    const runPrint = async () => {
      const docFonts = (document as Document & { fonts?: { ready: Promise<unknown> } }).fonts;
      if (docFonts?.ready) await docFonts.ready.catch(() => {});
      await new Promise((resolve) => window.setTimeout(resolve, 120));
      if (!cancelled) window.print();
    };
    runPrint();
    return () => {
      cancelled = true;
    };
  }, [printRows]);

  const resendSms = useCallback(
    async (d: Drum) => {
      if (!d.mobile_number) {
        toast.error("মোবাইল নাম্বার নেই");
        return;
      }
      setResendingId(d.id);
      try {
        const { message } = renderSms(settings.smsTemplate, d, drums);
        const res = await sendBulkSms({ data: { number: d.mobile_number, message } });
        if (res.ok) {
          markSmsSent(d.id, true);
          toast.success("SMS পাঠানো হয়েছে");
        } else {
          toast.error(`SMS পাঠানো যায়নি${res.code ? ` (কোড ${res.code})` : ""}`);
        }
      } catch {
        toast.error("SMS পাঠানো যায়নি");
      } finally {
        setResendingId(null);
      }
    },
    [settings.smsTemplate, drums, markSmsSent],
  );


  const sendViaApp = useCallback(
    (d: Drum) => {
      if (!d.mobile_number) {
        toast.error("মোবাইল নাম্বার নেই");
        return;
      }
      const { message } = renderSms(settings.smsAppTemplate, d, drums);
      const href = `sms:${d.mobile_number}?body=${encodeURIComponent(message)}`;
      markSmsSent(d.id, true);
      window.location.href = href;
    },
    [settings.smsAppTemplate, drums, markSmsSent],
  );


  const sendNextViaApp = useCallback(
    (d: Drum) => {
      if (!d.mobile_number) {
        toast.error("মোবাইল নাম্বার নেই");
        return;
      }
      const { message } = renderSms(settings.nextSmsTemplate, d, drums);
      const href = `sms:${d.mobile_number}?body=${encodeURIComponent(message)}`;
      window.location.href = href;
    },
    [settings.nextSmsTemplate, drums],
  );

  const toggleSent = useCallback(
    (d: Drum) => {
      const next = !d.sms_sent;
      markSmsSent(d.id, next);
      toast.success(next ? "পাঠানো হিসেবে চিহ্নিত" : "চিহ্ন সরানো হয়েছে");
    },
    [markSmsSent],
  );

  const scoped = useMemo(() => {
    if (tab === "manual") return drums.filter((d) => d.source !== "call_recording");
    if (tab === "auto") return drums.filter((d) => d.source === "call_recording");
    return drums;
  }, [drums, tab]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return scoped;
    return scoped.filter((d) =>
      [d.customer_name, d.drum_number, d.village, d.mobile_number, String(d.serial_number)]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(q)),
    );
  }, [scoped, query]);

  const remove = useCallback(
    async (id: string) => {
      if (!confirm("এই এন্ট্রি মুছে ফেলবেন?")) return;
      const ok = await deleteDrum(id);
      if (ok) toast.success("মুছে ফেলা হয়েছে");
    },
    [deleteDrum],
  );

  const edit = useCallback((d: Drum) => setEditing(d), []);

  async function handleReset() {
    const first = confirm(
      "সব সিরিয়াল রিসেট হবে এবং সিরিয়াল নাম্বার আবার ১ থেকে শুরু হবে। আপনি কি নিশ্চিত?",
    );
    if (!first) return;
    const second = confirm("এটি undo করা যাবে না। সত্যিই সব মুছে ফেলবেন?");
    if (!second) return;
    const ok = await resetAll();
    if (ok) toast.success("সব সিরিয়াল রিসেট হয়েছে");
  }


  async function downloadPDF() {
    return generatePDF("save");
  }
  async function printPDF() {
    if (filtered.length === 0) {
      toast.error("প্রিন্ট করার মতো কোন এন্ট্রি নেই");
      return;
    }
    setPrintRows([...filtered].sort((a, b) => a.serial_number - b.serial_number));
  }
  async function generatePDF(mode: "save") {
    if (filtered.length === 0) {
      toast.error("এক্সপোর্ট করার মতো কোন এন্ট্রি নেই");
      return;
    }


    const rows = [...filtered].sort((a, b) => a.serial_number - b.serial_number);
    const title = "আস্থা ফার্মেসী";
    const address = "পীরগঞ্জ, ঠাকুরগাঁও";
    const chamberDays = "ডাক্তার বসার দিন: রবি, মঙ্গল, বুধ, শুক্র";

    // Clinic days: Sun(0), Tue(2), Wed(3), Fri(5).
    // Mon->Tue, Sat->Sun, Thu->Fri. Others map forward to next clinic day.
    const clinicDays = [0, 2, 3, 5];
    const now = new Date();
    const target = new Date(now);
    for (let i = 0; i < 7; i++) {
      if (clinicDays.includes(target.getDay())) break;
      target.setDate(target.getDate() + 1);
    }
    const banglaDays = ["রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"];
    const dayName = banglaDays[target.getDay()];
    const dateStr = target.toLocaleDateString("bn-BD", { day: "numeric", month: "long", year: "numeric" });
    const dateLine = `${dayName} — ${dateStr}`;

    try {
      const docFonts = (document as Document & {
        fonts?: { ready: Promise<unknown>; load: (f: string) => Promise<unknown> };
      }).fonts;
      if (docFonts?.load) {
        await Promise.all([
          docFonts.load("400 14px 'Noto Sans Bengali'"),
          docFonts.load("600 16px 'Noto Sans Bengali'"),
          docFonts.load("700 28px 'Noto Sans Bengali'"),
        ]).catch(() => {});
      }
      if (docFonts?.ready) await docFonts.ready;
      await new Promise((r) => setTimeout(r, 80));

      const { jsPDF } = await import("jspdf");
      const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();

      const cssWidth = 794;
      const cssHeight = 1123;
      const scale = 2;
      const margin = 44;
      const tableWidth = cssWidth - margin * 2;
      const columns = [74, 205, 132, 125, tableWidth - 74 - 205 - 132 - 125];
      const headers = ["সিরিয়াল", "নাম", "গ্রাম", "মোবাইল", "সময়"];
      const fontFamily = "'Noto Sans Bengali', system-ui, sans-serif";
      const lineHeight = 18;
      const fmtPdfDateTime = (iso: string) => {
        const dt = new Date(iso);
        const dd = String(dt.getDate()).padStart(2, "0");
        const mm = String(dt.getMonth() + 1).padStart(2, "0");
        const yy = String(dt.getFullYear()).slice(-2);
        const time = dt.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
        return `${dd}.${mm}.${yy},${time}`;
      };

      const makeCanvas = () => {
        const canvas = document.createElement("canvas");
        canvas.width = cssWidth * scale;
        canvas.height = cssHeight * scale;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("Canvas not supported");
        ctx.scale(scale, scale);
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, cssWidth, cssHeight);
        ctx.textBaseline = "top";
        ctx.direction = "ltr";
        return { canvas, ctx };
      };

      const setFont = (ctx: CanvasRenderingContext2D, size: number, weight = 400) => {
        ctx.font = `${weight} ${size}px ${fontFamily}`;
      };

      const wrapText = (ctx: CanvasRenderingContext2D, value: unknown, maxWidth: number) => {
        const raw = String(value ?? "");
        const segments = raw.split(/\n/);
        const out: string[] = [];
        for (const segment of segments) {
          const text = segment.trim();
          if (!text) {
            out.push("");
            continue;
          }
          const lines: string[] = [];
          let line = "";
          const words = text.split(/\s+/);
          const pushChunk = (chunk: string) => {
            for (const char of chunk) {
              const next = line + char;
              if (line && ctx.measureText(next).width > maxWidth) {
                lines.push(line);
                line = char;
              } else {
                line = next;
              }
            }
          };
          for (const word of words) {
            const next = line ? `${line} ${word}` : word;
            if (ctx.measureText(next).width <= maxWidth) {
              line = next;
            } else if (ctx.measureText(word).width > maxWidth) {
              if (line) {
                lines.push(line);
                line = "";
              }
              pushChunk(word);
            } else {
              if (line) lines.push(line);
              line = word;
            }
          }
          if (line) lines.push(line);
          out.push(...(lines.length ? lines : [""]));
        }
        return out.length ? out : [""];
      };

      const drawCentered = (
        ctx: CanvasRenderingContext2D,
        text: string,
        y: number,
        size: number,
        weight: number,
        color: string,
      ) => {
        setFont(ctx, size, weight);
        ctx.fillStyle = color;
        ctx.textAlign = "center";
        ctx.fillText(text, cssWidth / 2, y);
      };

      const drawHeader = (ctx: CanvasRenderingContext2D, withChamber: boolean) => {
        if (!withChamber) return 40;

        drawCentered(ctx, title, 36, 28, 700, "#14110c");
        drawCentered(ctx, address, 75, 17, 600, "#4d4537");
        drawCentered(ctx, chamberDays, 102, 13, 500, "#5d564b");
        drawCentered(ctx, dateLine, 125, 14, 600, "#8a6a20");

        ctx.strokeStyle = "#d8d1c2";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(margin, 158);
        ctx.lineTo(cssWidth - margin, 158);
        ctx.stroke();

        let x = margin;
        const y = 176;
        const h = 36;
        setFont(ctx, 13, 700);
        headers.forEach((header, i) => {
          ctx.fillStyle = "#f6f1e7";
          ctx.fillRect(x, y, columns[i], h);
          ctx.strokeStyle = "#cfc8b8";
          ctx.strokeRect(x, y, columns[i], h);
          ctx.fillStyle = "#14110c";
          ctx.textAlign = i === 0 ? "center" : "left";
          ctx.fillText(header, i === 0 ? x + columns[i] / 2 : x + 10, y + 9);
          x += columns[i];
        });
        return y + h;
      };

      const drawRow = (
        ctx: CanvasRenderingContext2D,
        d: Drum,
        y: number,
        prepared: { lines: string[][]; height: number },
      ) => {
        const values = [
          `#${String(d.serial_number).padStart(3, "0")}`,
          d.customer_name,
          d.village ?? "",
          d.mobile_number ?? "",
          fmtPdfDateTime(d.created_at),
        ];
        let x = margin;
        setFont(ctx, 13, 400);
        values.forEach((_, i) => {
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(x, y, columns[i], prepared.height);
          ctx.strokeStyle = "#d8d1c2";
          ctx.strokeRect(x, y, columns[i], prepared.height);
          ctx.fillStyle = i === 0 ? "#8a6a20" : "#14110c";
          setFont(ctx, i === 0 ? 13 : 12.5, i === 0 ? 700 : 400);
          ctx.textAlign = i === 0 ? "center" : "left";
          prepared.lines[i].slice(0, 3).forEach((line, lineIndex) => {
            const textX = i === 0 ? x + columns[i] / 2 : x + 10;
            ctx.fillText(line, textX, y + 10 + lineIndex * lineHeight);
          });
          x += columns[i];
        });
      };

      const addCanvasPage = (canvas: HTMLCanvasElement, isFirst: boolean) => {
        if (!isFirst) pdf.addPage();
        pdf.addImage(canvas.toDataURL("image/jpeg", 0.96), "JPEG", 0, 0, pageWidth, pageHeight);
      };

      let { canvas, ctx } = makeCanvas();
      let y = drawHeader(ctx, true);
      let firstPage = true;
      const bottomLimit = cssHeight - 46;

      for (const d of rows) {
        setFont(ctx, 12.5, 400);
        const values = [
          `#${String(d.serial_number).padStart(3, "0")}`,
          d.customer_name,
          d.village ?? "",
          d.mobile_number ?? "",
          fmtPdfDateTime(d.created_at),
        ];
        const lines = values.map((value, i) => (i === 4 ? [String(value ?? "")] : wrapText(ctx, value, columns[i] - 20)));
        const height = Math.max(42, 20 + Math.max(...lines.map((l) => Math.min(l.length, 3))) * lineHeight);
        if (y + height > bottomLimit) {
          addCanvasPage(canvas, firstPage);
          firstPage = false;
          ({ canvas, ctx } = makeCanvas());
          y = drawHeader(ctx, false);
        }
        drawRow(ctx, d, y, { lines, height });
        y += height;
      }

      addCanvasPage(canvas, firstPage);

      pdf.save(`doctor-serial-${new Date().toISOString().slice(0, 10)}.pdf`);

    } catch (error) {
      console.error(error);
      toast.error("PDF তৈরি করা যায়নি");
    }
  }




  return (
    <div className="min-h-dvh">
      <Toaster position="top-center" richColors />
      <div className="mx-auto max-w-xl px-4 pb-28 pt-6">
        <header className="grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-2 pb-5">
          <div className="min-w-0">
            <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-muted-foreground">
              Dr.
            </p>
            <h1 className="font-display truncate text-3xl font-semibold leading-tight text-foreground">
              Total Serial
            </h1>
          </div>
          <ActionsMenu onPdf={downloadPDF} onPrint={printPDF} onReset={handleReset} />
          <SettingsButton
            settings={settings}
            save={save}
            replaceSavedNames={replaceSavedNames}
            replaceSavedVillages={replaceSavedVillages}
            replaceSavedMobiles={replaceSavedMobiles}
          />
        </header>

          <div className="hairline-gold h-px w-full opacity-70" />

        <div className="mt-3">
          <CallRecordingPanel onSerialCreated={() => void reloadDrums()} />
        </div>

        <div className="mb-1 flex gap-1.5 rounded-xl border border-border bg-card p-1">
          {([
            ["all", "সব"],
            ["manual", "ম্যানুয়াল"],
            ["auto", "অটো"],
          ] as const).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setTab(key)}
              className={`flex-1 rounded-lg px-3 py-2 text-xs font-semibold transition-colors ${
                tab === key
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-secondary"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <p className="mt-3 text-xs text-muted-foreground">
          {scoped.length} এর মধ্যে {filtered.length} এন্ট্রি
        </p>



        <div className="mt-2 mb-4 flex items-center gap-2 rounded-xl border border-input bg-card px-3 shadow-sm focus-within:ring-2 focus-within:ring-ring/40">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="নাম, গ্রাম, মোবাইল বা সিরিয়াল খুঁজুন…"
            className="w-full bg-transparent py-2.5 text-sm outline-none"
          />
        </div>

        {loading ? (
          <div className="grid place-items-center py-12 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="card-premium grid place-items-center px-6 py-12 text-center">
            <p className="font-display text-lg text-foreground">কোন এন্ট্রি নেই</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {query ? "আপনার সার্চের সাথে কিছু মিলছে না।" : "Entry ট্যাব থেকে প্রথম এন্ট্রি যোগ করুন।"}
            </p>
          </div>
        ) : (
          <ul className="space-y-2.5">
            {filtered.map((d) => (
              <Row
                key={d.id}
                d={d}
                expanded={activeId === d.id}
                onToggle={() => setActiveId((cur) => (cur === d.id ? null : d.id))}
                onDelete={() => setConfirmDelete(d)}
                onEdit={edit}
                onResend={resendSms}
                onSendApp={sendViaApp}
                onSendNext={sendNextViaApp}
                onToggleSent={toggleSent}
                resending={resendingId === d.id}
              />
            ))}
          </ul>

        )}
      </div>

      {confirmDelete && (
        <ConfirmDialog
          title="এন্ট্রি ডিলিট করবেন?"
          description={`সিরিয়াল #${String(confirmDelete.serial_number).padStart(3, "0")} — ${confirmDelete.customer_name} মুছে ফেলা হবে।`}
          confirmLabel="ডিলিট করুন"
          onCancel={() => setConfirmDelete(null)}
          onConfirm={async () => {
            const id = confirmDelete.id;
            setConfirmDelete(null);
            const ok = await deleteDrum(id);
            if (ok) toast.success("মুছে ফেলা হয়েছে");
          }}
        />
      )}

      {editing && (
        <EditDialog
          drum={editing}
          onClose={() => setEditing(null)}
          onSave={async (patch) => {
            const row = await updateDrum(editing.id, patch);
            if (row) {
              if (patch.customer_name) rememberName(patch.customer_name);
              if (patch.village) rememberVillage(patch.village);
              if (patch.mobile_number) rememberMobile(patch.mobile_number);
              toast.success("আপডেট হয়েছে");
              setEditing(null);
            }
          }}
        />
      )}

      {printRows && <PrintLayout rows={printRows} onClose={() => setPrintRows(null)} />}

      
    </div>
  );
}

function PrintLayout({ rows, onClose }: { rows: Drum[]; onClose: () => void }) {
  const clinicDays = [0, 2, 3, 5];
  const target = new Date();
  for (let i = 0; i < 7; i++) {
    if (clinicDays.includes(target.getDay())) break;
    target.setDate(target.getDate() + 1);
  }
  const banglaDays = ["রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"];
  const dateLine = `${banglaDays[target.getDay()]} — ${target.toLocaleDateString("bn-BD", {
    day: "numeric",
    month: "long",
    year: "numeric",
  })}`;
  const fmtPrintDateTime = (iso: string) => {
    const dt = new Date(iso);
    const dd = String(dt.getDate()).padStart(2, "0");
    const mm = String(dt.getMonth() + 1).padStart(2, "0");
    const yy = String(dt.getFullYear()).slice(-2);
    const time = dt.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    return `${dd}.${mm}.${yy},${time}`;
  };

  return createPortal(
    <div className="print-shell fixed inset-0 z-[80] overflow-auto bg-background p-4 text-foreground">
      <div className="print-toolbar mx-auto mb-4 flex max-w-4xl items-center justify-between gap-3 rounded-xl border border-border bg-card p-3 shadow-xl">
        <p className="text-sm font-semibold">Print layout ready</p>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => window.print()}
            className="btn-premium rounded-xl px-4 py-2 text-sm font-semibold"
          >
            Print
          </button>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-border bg-card px-4 py-2 text-sm font-semibold text-foreground hover:bg-secondary"
          >
            Close
          </button>
        </div>
      </div>
      <section className="print-page mx-auto bg-white text-neutral-950 shadow-2xl">
        <header className="print-header text-center">
          <h1>আস্থা ফার্মেসী</h1>
          <p>পীরগঞ্জ, ঠাকুরগাঁও</p>
          <p>ডাক্তার বসার দিন: রবি, মঙ্গল, বুধ, শুক্র</p>
          <p className="print-date">{dateLine}</p>
        </header>
        <table className="print-table">
          <thead>
            <tr>
              <th>সিরিয়াল</th>
              <th>নাম</th>
              <th>গ্রাম</th>
              <th>মোবাইল</th>
              <th>সময়</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((d) => (
              <tr key={d.id}>
                <td className="print-serial">#{String(d.serial_number).padStart(3, "0")}</td>
                <td>{d.customer_name}</td>
                <td>{d.village ?? ""}</td>
                <td>{d.mobile_number ?? ""}</td>
                <td className="print-time">{fmtPrintDateTime(d.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>,
    document.body,
  );
}

function ActionsMenu({ onPdf, onPrint, onReset }: { onPdf: () => void; onPrint: () => void; onReset: () => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);
  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="আরও অ্যাকশন"
        aria-haspopup="menu"
        aria-expanded={open}
        className="grid h-11 w-11 place-items-center rounded-xl border border-border bg-card text-foreground transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
      >
        <MoreVertical className="h-4 w-4" />
      </button>
      {open && (
        <div className="absolute right-0 top-11 z-40 w-56 overflow-hidden rounded-xl border border-border bg-card shadow-xl">
          <button
            onClick={() => { setOpen(false); onPrint(); }}
            className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-left text-sm text-foreground hover:bg-secondary"
          >
            <Printer className="h-4 w-4" />
            ডাইরেক্ট প্রিন্ট
          </button>
          <div className="h-px bg-border" />
          <button
            onClick={() => { setOpen(false); onPdf(); }}
            className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-left text-sm text-foreground hover:bg-secondary"
          >
            <FileDown className="h-4 w-4" />
            PDF ডাউনলোড
          </button>

          <div className="h-px bg-border" />
          <button
            onClick={() => { setOpen(false); onReset(); }}
            className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-left text-sm text-destructive hover:bg-destructive/10"
          >
            <Trash2 className="h-4 w-4" />
            সব সিরিয়াল মুছুন
          </button>
        </div>
      )}
    </div>
  );
}

const Row = memo(function Row({
  d,
  expanded,
  onToggle,
  onDelete,
  onEdit,
  onResend,
  onSendApp,
  onSendNext,
  onToggleSent,
  resending,
}: {
  d: Drum;
  expanded: boolean;
  onToggle: () => void;
  onDelete: () => void;
  onEdit: (d: Drum) => void;
  onResend: (d: Drum) => void;
  onSendApp: (d: Drum) => void;
  onSendNext: (d: Drum) => void;
  onToggleSent: (d: Drum) => void;
  resending: boolean;
}) {
  const hasMobile = Boolean(d.mobile_number);
  const time = isToday(d.created_at) ? fmtTime(d.created_at) : fmtDate(d.created_at);
  return (
    <li className="card-premium overflow-hidden">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={expanded}
        className="grid w-full grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 px-3 py-3 text-left transition-colors hover:bg-secondary/40"
      >
        <div className="flex flex-col items-center justify-center rounded-xl border border-[color-mix(in_oklab,var(--gold)_25%,var(--color-border))] bg-[color-mix(in_oklab,var(--gold)_8%,transparent)] px-3 py-1.5">
          <span className="text-[9px] font-semibold uppercase tracking-widest text-muted-foreground">
            সিরিয়াল
          </span>
          <span className="num-premium text-2xl font-bold text-primary leading-tight">
            #{String(d.serial_number).padStart(3, "0")}
          </span>
        </div>

        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <p className="truncate font-display text-lg font-semibold text-foreground">
              {d.customer_name}
            </p>
            {d.sms_sent && (
              <span className="inline-grid h-4 w-4 place-items-center rounded-full bg-emerald-500/20 text-emerald-600">
                <Check className="h-3 w-3" strokeWidth={3} />
              </span>
            )}
            <span
              className={`shrink-0 rounded-full px-1.5 py-0.5 text-[9px] font-semibold ${
                d.source === "call_recording"
                  ? "bg-sky-500/15 text-sky-600"
                  : "bg-secondary text-muted-foreground"
              }`}
            >
              {d.source === "call_recording" ? "কল" : "ম্যানুয়াল"}
            </span>
          </div>
          <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
            {d.village && (
              <span className="inline-flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                <span className="truncate">{d.village}</span>
              </span>
            )}
            {d.mobile_number && (
              <span className="inline-flex items-center gap-1">
                <Phone className="h-3 w-3" />
                <span className="tabular">{d.mobile_number}</span>
              </span>
            )}
            <span className="tabular text-[10px] opacity-70">{time}</span>
          </div>
        </div>

        <span
          aria-hidden
          className={`grid h-9 w-9 place-items-center rounded-full border border-border bg-card text-foreground shadow-sm transition-transform duration-300 ${
            expanded ? "rotate-180" : ""
          }`}
        >
          <ChevronDown className="h-4 w-4" />
        </span>
      </button>

      <div
        className={`grid overflow-hidden transition-[grid-template-rows] duration-300 ease-out ${
          expanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
        }`}
      >
        <div className="min-h-0 overflow-hidden">
          <div
            className="grid grid-cols-5 gap-1.5 px-3 py-3"
            style={{
              background:
                "linear-gradient(135deg, color-mix(in oklab, var(--gold) 78%, black 6%), color-mix(in oklab, var(--gold) 62%, black 14%))",
            }}
          >
            <ActionIcon
              label="নোটিফিকেশন"
              onClick={() => hasMobile && onSendNext(d)}
              disabled={!hasMobile}
            >
              <BellRing className="h-5 w-5" />
            </ActionIcon>
            <ActionIcon label="এডিট" onClick={() => onEdit(d)}>
              <Pencil className="h-5 w-5" />
            </ActionIcon>
            <ActionIcon
              label="SMS পাঠান"
              onClick={() => hasMobile && onSendApp(d)}
              disabled={!hasMobile}
            >
              {resending ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
            </ActionIcon>
            <ActionIcon
              label={d.sms_sent ? "সম্পন্ন" : "সম্পন্ন করুন"}
              onClick={() => onToggleSent(d)}
              tone={d.sms_sent ? "success-filled" : "outline"}
            >
              <Check className="h-5 w-5" strokeWidth={d.sms_sent ? 3 : 2.25} />
            </ActionIcon>

            <ActionIcon label="ডিলিট" onClick={onDelete} tone="danger">
              <Trash2 className="h-5 w-5" />
            </ActionIcon>
          </div>
        </div>
      </div>
    </li>
  );
});

function ActionIcon({
  children,
  label,
  onClick,
  disabled,
  tone = "default",
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  tone?: "default" | "danger" | "success" | "success-filled" | "outline";
}) {
  const toneClass =
    tone === "danger"
      ? "bg-white text-red-600"
      : tone === "success"
        ? "bg-white text-emerald-600"
        : tone === "success-filled"
          ? "bg-emerald-500 text-white ring-emerald-300 shadow-emerald-900/30"
          : tone === "outline"
            ? "bg-white/10 text-white/90 ring-white/40 shadow-none"
            : "bg-white text-neutral-800";
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="flex flex-col items-center gap-1 rounded-xl px-1 py-1.5 text-[10px] font-medium text-white/95 transition-transform active:scale-95 disabled:opacity-40 disabled:pointer-events-none"
    >
      <span
        className={`grid h-10 w-10 place-items-center rounded-full shadow-md ring-1 ring-black/5 transition-colors ${toneClass}`}
      >
        {children}
      </span>
      <span className="truncate leading-none">{label}</span>
    </button>
  );
}


function ConfirmDialog({
  title,
  description,
  confirmLabel,
  onConfirm,
  onCancel,
}: {
  title: string;
  description: string;
  confirmLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (typeof document === "undefined") return null;
  return createPortal(
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4 animate-in fade-in duration-150"
      onClick={onCancel}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-2xl animate-in zoom-in-95 fade-in duration-150"
      >
        <h3 className="font-display text-xl font-semibold text-foreground">{title}</h3>
        <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>
        <div className="mt-5 flex gap-2">
          <button
            onClick={onCancel}
            className="flex-1 rounded-xl border border-border bg-card px-3 py-2.5 text-sm font-semibold text-foreground hover:bg-secondary"
          >
            বাতিল
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 rounded-xl bg-red-600 px-3 py-2.5 text-sm font-semibold text-white hover:bg-red-700"
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}


function EditDialog({
  drum,
  onClose,
  onSave,
}: {
  drum: Drum;
  onClose: () => void;
  onSave: (patch: {
    customer_name: string;
    village: string | null;
    mobile_number: string | null;
    drum_number: string | null;
  }) => Promise<void>;
}) {
  const [name, setName] = useState(drum.customer_name);
  const [village, setVillage] = useState(drum.village ?? "");
  
  const initMobile = (drum.mobile_number ?? "").startsWith("01")
    ? (drum.mobile_number ?? "").slice(2)
    : (drum.mobile_number ?? "");
  const [mobileRest, setMobileRest] = useState(initMobile);
  const [saving, setSaving] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const n = name.trim();
    if (!n) {
      toast.error("নাম দিন");
      return;
    }
    const digits = mobileRest.replace(/\D/g, "").slice(0, 9);
    const fullMobile = digits ? "01" + digits : "";
    if (fullMobile && fullMobile.length !== 11) {
      toast.error("মোবাইল নাম্বার ১১ ডিজিট হতে হবে");
      return;
    }
    setSaving(true);
    await onSave({
      customer_name: n,
      village: village.trim() || null,
      mobile_number: fullMobile || null,
      drum_number: null,
    });
    setSaving(false);
  }

  if (typeof document === "undefined") return null;
  return createPortal(
    <div
      className="fixed inset-0 z-50 grid place-items-center overscroll-contain bg-black/40 p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <form
        onClick={(e) => e.stopPropagation()}
        onSubmit={submit}
        className="relative flex max-h-[85vh] w-full max-w-md flex-col gap-3 overflow-y-auto rounded-2xl border border-border bg-card p-5 shadow-2xl animate-in zoom-in-95 fade-in duration-200"
      >
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-muted-foreground">
              সিরিয়াল সম্পাদনা
            </p>
            <h2 className="num-premium text-2xl font-bold text-primary">
              #{String(drum.serial_number).padStart(3, "0")}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-2 text-muted-foreground hover:bg-secondary"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div>
          <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            নাম
          </label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="input-premium"
          />
        </div>
        <div>
          <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            গ্রাম
          </label>
          <input
            value={village}
            onChange={(e) => setVillage(e.target.value)}
            className="input-premium"
          />
        </div>
        <div>
          <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            মোবাইল নাম্বার
          </label>
          <div className="flex items-stretch overflow-hidden rounded-xl border border-input bg-background focus-within:ring-2 focus-within:ring-ring/40">
            <span className="grid select-none place-items-center border-r border-border bg-secondary px-3 font-mono text-sm font-semibold tabular text-secondary-foreground">
              01
            </span>
            <input
              type="tel"
              inputMode="numeric"
              maxLength={9}
              value={mobileRest}
              onChange={(e) =>
                setMobileRest(bnToEnDigits(e.target.value).replace(/\D/g, "").slice(0, 9))
              }
              className="w-full bg-transparent px-3 py-3 text-base tabular outline-none"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="btn-premium mt-2 flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold uppercase tracking-wider disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
          পরিবর্তন সংরক্ষণ করুন
        </button>
      </form>
    </div>,
    document.body,
  );
}
