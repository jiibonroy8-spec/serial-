import { Link, useRouterState } from "@tanstack/react-router";
import { PlusCircle, ListOrdered } from "lucide-react";

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const items = [
    { to: "/", label: "Entry", icon: PlusCircle },
    { to: "/ledger", label: "List", icon: ListOrdered },
  ] as const;

  return (
    <nav
      aria-label="Primary"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-border/60 bg-card/85 backdrop-blur-xl pb-[env(safe-area-inset-bottom)]"
    >
      <div className="mx-auto grid max-w-xl grid-cols-2">
        {items.map((it) => {
          const active = pathname === it.to;
          const Icon = it.icon;
          return (
            <Link
              key={it.to}
              to={it.to}
              preload="intent"
              aria-current={active ? "page" : undefined}
              className="group relative flex min-h-14 items-center justify-center py-2 outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
            >
              <span
                className={`flex flex-col items-center gap-1 rounded-2xl px-5 py-1.5 text-[11px] font-semibold uppercase tracking-wider transition-all duration-200 ${
                  active
                    ? "text-primary"
                    : "text-muted-foreground group-hover:text-foreground"
                }`}
              >
                <Icon
                  className={`h-5 w-5 transition-transform duration-200 ${
                    active ? "scale-110" : ""
                  }`}
                  strokeWidth={active ? 2.4 : 2}
                />
                {it.label}
              </span>
              {active && (
                <span
                  aria-hidden
                  className="absolute inset-x-8 top-0 h-[2px] rounded-full bg-primary shadow-[0_0_10px_color-mix(in_oklab,var(--primary)_60%,transparent)]"
                />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
