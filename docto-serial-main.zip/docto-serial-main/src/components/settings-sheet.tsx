import { X, Settings2, Check, ChevronRight, ChevronLeft, Palette, MessageSquare, Users, MapPin, Phone, Sliders, Trash2, Pencil, Sheet, BellOff, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { THEME_PRESETS, DEFAULT_SETTINGS, DEFAULT_CHAMBER_CLOSED_TEMPLATE, refreshSerialSuggestions, type Settings } from "@/hooks/use-settings";
import { useDrums } from "@/hooks/use-drums";
import { sendBulkSmsMany } from "@/lib/send-sms.functions";
import { previewSms } from "@/lib/sms";

function NextSmsEditor({ value, onSave }: { value: string; onSave: (v: string) => void }) {
  const [draft, setDraft] = useState(value);
  const [savedFlash, setSavedFlash] = useState(false);
  const dirty = draft !== value;
  const preview = previewSms(draft);
  const commit = () => {
    onSave(draft);
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 1500);
  };
  return (
    <div className="space-y-2.5">
      <textarea
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        rows={5}
        className="input-premium resize-none text-sm leading-relaxed"
      />
      <div className="rounded-xl border border-border bg-background/60 p-3 text-[11px] leading-relaxed text-muted-foreground">
        <p className="mb-1 font-semibold text-foreground">উপলব্ধ ভ্যারিয়েবল:</p>
        <p><code className="text-primary">{"{{name}}"}</code> — রোগীর নাম</p>
        <p><code className="text-primary">{"{{serial}}"}</code> — সিরিয়াল নম্বর</p>
        <p className="mt-1 opacity-70">(পুরনো {"{patient_name}"} / {"{serial}"} ফরম্যাটও কাজ করবে)</p>
      </div>
      <div>
        <p className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">প্রিভিউ (সুমা · ৩৫)</p>
        <div className="whitespace-pre-wrap rounded-xl border border-primary/30 bg-[color-mix(in_oklab,var(--primary)_6%,transparent)] p-3 text-sm leading-relaxed text-foreground">
          {preview || <span className="text-muted-foreground">টেমপ্লেট লিখুন…</span>}
        </div>
      </div>
      <div className="flex gap-2">
        <button
          onClick={commit}
          disabled={!dirty && !savedFlash}
          className="flex-1 rounded-xl bg-primary py-2.5 text-xs font-semibold text-primary-foreground disabled:opacity-60"
        >
          {savedFlash ? "✓ সেভ হয়েছে" : dirty ? "সেভ করুন" : "সেভড"}
        </button>
        <button
          onClick={() => setDraft(DEFAULT_SETTINGS.nextSmsTemplate)}
          className="rounded-xl border border-border bg-background px-3 text-xs font-semibold hover:bg-secondary"
        >
          Default
        </button>
      </div>
    </div>
  );
}

type SectionKey = "branding" | "theme" | "sms" | "closed" | "names" | "villages" | "mobiles" | "sheet";

const SECTIONS: {
  key: SectionKey;
  title: string;
  icon: React.ReactNode;
  subtitle: (s: Settings) => string;
}[] = [
  { key: "branding", title: "Branding", icon: <Sliders className="h-4 w-4" />, subtitle: (s) => s.brandName },
  { key: "theme", title: "Theme", icon: <Palette className="h-4 w-4" />, subtitle: (s) => THEME_PRESETS.find((t) => t.id === s.theme)?.label ?? "" },
  { key: "sms", title: "Bulk SMS", icon: <MessageSquare className="h-4 w-4" />, subtitle: (s) => (s.bulkSmsEnabled ? "চালু" : "বন্ধ") },
  { key: "closed", title: "চেম্বার বন্ধ ঘোষণা", icon: <BellOff className="h-4 w-4" />, subtitle: () => "সবাইকে এক ক্লিকে জানান" },
  { key: "sheet", title: "Google Sheet Backup", icon: <Sheet className="h-4 w-4" />, subtitle: (s) => (s.sheetWebhookUrl.trim() ? "সংযুক্ত" : "সংযুক্ত নয়") },
  { key: "names", title: "নাম সংরক্ষিত", icon: <Users className="h-4 w-4" />, subtitle: (s) => `${s.savedNames.length} টি` },
  { key: "villages", title: "গ্রাম সংরক্ষিত", icon: <MapPin className="h-4 w-4" />, subtitle: (s) => `${s.savedVillages.length} টি` },
  { key: "mobiles", title: "নাম্বার সংরক্ষিত", icon: <Phone className="h-4 w-4" />, subtitle: (s) => `${(s.savedMobiles ?? []).length} টি` },
];

export function SettingsButton({
  settings,
  save,
  replaceSavedNames,
  replaceSavedVillages,
  replaceSavedMobiles,
}: {
  settings: Settings;
  save: (s: Settings) => void;
  replaceSavedNames: (next: string[]) => void;
  replaceSavedVillages: (next: string[]) => void;
  replaceSavedMobiles: (next: string[]) => void;
}) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<SectionKey | null>(null);

  const activeMeta = SECTIONS.find((s) => s.key === active);

  // Keep the saved name / village / mobile counts in sync with the database.
  useEffect(() => {
    if (!open) return;
    void refreshSerialSuggestions();
  }, [open, active]);

  const close = () => {
    setOpen(false);
    setActive(null);
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label="Settings"
        className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-border bg-card text-foreground shadow-sm transition-colors hover:bg-secondary"
      >
        <Settings2 className="h-5 w-5" />
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-stretch justify-end bg-black/50 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={close}
        >
          <div
            className="flex h-full w-full max-w-md flex-col overflow-hidden bg-card shadow-2xl animate-in slide-in-from-right duration-300 ease-out"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 border-b border-border px-4 py-4">
              <div className="relative h-9 w-9 shrink-0">
                <button
                  onClick={() => setActive(null)}
                  aria-label="Back"
                  className={`absolute inset-0 grid place-items-center rounded-full border border-border bg-background transition-all duration-200 hover:bg-secondary ${
                    active ? "opacity-100 scale-100" : "opacity-0 scale-75 pointer-events-none"
                  }`}
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
              </div>
              <div key={active ?? "root"} className="min-w-0 flex-1 animate-in fade-in slide-in-from-right-2 duration-200">
                <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-muted-foreground">
                  {active ? "Settings" : "Customize"}
                </p>
                <h3 className="truncate font-display text-xl font-semibold">
                  {active ? activeMeta?.title : "Settings"}
                </h3>
              </div>
              <button
                onClick={close}
                aria-label="Close"
                className="grid h-9 w-9 place-items-center rounded-full border border-border bg-background hover:bg-secondary"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div key={active ?? "root-body"} className="flex-1 overflow-y-auto px-4 py-4 animate-in fade-in slide-in-from-right-4 duration-300 ease-out">
              {!active && (
                <div className="space-y-2">
                  {SECTIONS.map((s) => (
                    <button
                      key={s.key}
                      onClick={() => setActive(s.key)}
                      className="flex w-full items-center gap-3 rounded-2xl border border-border bg-background/50 px-4 py-3 text-left hover:bg-secondary/60"
                    >
                      <span className="grid h-9 w-9 place-items-center rounded-lg border border-border bg-card text-primary">
                        {s.icon}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-semibold text-foreground">{s.title}</p>
                        <p className="truncate text-[11px] text-muted-foreground">
                          {s.subtitle(settings)}
                        </p>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </button>
                  ))}

                  <button
                    onClick={() => save(DEFAULT_SETTINGS)}
                    className="mt-2 w-full rounded-xl border border-border bg-background py-2.5 text-sm font-medium hover:bg-secondary"
                  >
                    Reset to default
                  </button>
                </div>
              )}

              {active === "branding" && (
                <div className="space-y-3">
                  <Labeled label="Brand Name">
                    <input
                      type="text"
                      value={settings.brandName}
                      onChange={(e) => save({ ...settings, brandName: e.target.value })}
                      className="input-premium"
                    />
                  </Labeled>
                  <Labeled label="Tagline">
                    <input
                      type="text"
                      value={settings.tagline}
                      onChange={(e) => save({ ...settings, tagline: e.target.value })}
                      className="input-premium"
                    />
                  </Labeled>
                </div>
              )}

              {active === "theme" && (
                <div>
                  <div className="grid grid-cols-2 gap-2">
                    {THEME_PRESETS.map((t) => {
                      const isActive = settings.theme === t.id;
                      return (
                        <button
                          key={t.id}
                          onClick={() => save({ ...settings, theme: t.id })}
                          className={`relative flex flex-col gap-2 rounded-xl border p-2.5 text-left transition-all ${
                            isActive
                              ? "border-primary bg-[color-mix(in_oklab,var(--primary)_12%,transparent)] shadow-sm"
                              : "border-border bg-background hover:bg-secondary"
                          }`}
                        >
                          <div className="flex h-8 overflow-hidden rounded-md border border-border">
                            {t.swatch.map((c, i) => (
                              <span key={i} className="flex-1" style={{ background: c }} />
                            ))}
                          </div>
                          <div>
                            <p className="text-sm font-medium leading-tight">{t.label}</p>
                            <p className="text-[10px] leading-tight text-muted-foreground">
                              {t.description}
                            </p>
                          </div>
                          {isActive && (
                            <span className="absolute right-2 top-2 grid h-5 w-5 place-items-center rounded-full bg-primary text-primary-foreground">
                              <Check className="h-3 w-3" />
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                  <div className="mt-4">
                    <label className="mb-1 block text-[11px] text-muted-foreground">
                      Accent hue tint ({settings.accentHue}°)
                    </label>
                    <input
                      type="range"
                      min={0}
                      max={360}
                      value={settings.accentHue}
                      onChange={(e) => save({ ...settings, accentHue: Number(e.target.value) })}
                      className="w-full accent-[color:var(--primary)]"
                    />
                  </div>
                </div>
              )}

              {active === "sms" && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between rounded-xl border border-border bg-background px-3 py-3">
                    <div>
                      <p className="text-sm font-medium">Bulk SMS পাঠানো</p>
                      <p className="text-xs text-muted-foreground">
                        সিরিয়াল সেভ হলে SMS প্রিভিউ দেখান
                      </p>
                    </div>
                    <Switch
                      checked={settings.bulkSmsEnabled}
                      onChange={(v) => save({ ...settings, bulkSmsEnabled: v })}
                    />
                  </div>
                  <div>
                    <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Bulk SMS টেমপ্লেট</p>
                    <SmsTemplateEditor
                      value={settings.smsTemplate}
                      onSave={(tpl) => save({ ...settings, smsTemplate: tpl })}
                    />
                  </div>
                  <div className="pt-2">
                    <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">SMS অ্যাপ টেমপ্লেট</p>
                    <p className="mb-2 text-[11px] text-muted-foreground">
                      লিস্টের ➤ Send বাটনে চাপলে মোবাইলের SMS অ্যাপে এই টেক্সট অটো-ফিল হবে।
                    </p>
                    <SmsTemplateEditor
                      value={settings.smsAppTemplate}
                      onSave={(tpl) => save({ ...settings, smsAppTemplate: tpl })}
                    />
                  </div>
                  <div className="pt-2">
                    <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">নোটিফিকেশন মেসেজ টেমপ্লেট (পরবর্তী সিরিয়াল)</p>
                    <p className="mb-2 text-[11px] text-muted-foreground">
                      লিস্টের 🔔 বাটনে চাপলে SMS অ্যাপে এই মেসেজ অটো-ফিল হবে।
                    </p>
                    <NextSmsEditor
                      value={settings.nextSmsTemplate}
                      onSave={(tpl) => save({ ...settings, nextSmsTemplate: tpl })}
                    />
                  </div>
                </div>
              )}

              {active === "closed" && (
                <ChamberClosedPanel
                  template={settings.chamberClosedTemplate}
                  onSaveTemplate={(tpl) => save({ ...settings, chamberClosedTemplate: tpl })}
                />
              )}

              {active === "names" && (
                <SuggestionList
                  items={settings.savedNames}
                  onUpdate={replaceSavedNames}
                  addPlaceholder="নতুন নাম যোগ করুন"
                  clearLabel="শুধু সাজেশন লিস্ট মুছুন"
                />
              )}

              {active === "villages" && (
                <SuggestionList
                  items={settings.savedVillages}
                  onUpdate={replaceSavedVillages}
                  addPlaceholder="নতুন গ্রাম যোগ করুন"
                  clearLabel="শুধু গ্রামের সাজেশন মুছুন"
                />
              )}

              {active === "mobiles" && (
                <SuggestionList
                  items={settings.savedMobiles ?? []}
                  onUpdate={replaceSavedMobiles}
                  addPlaceholder="নতুন নাম্বার যোগ করুন"
                  clearLabel="শুধু নাম্বারের সাজেশন মুছুন"
                />
              )}

              {active === "sheet" && (
                <SheetWebhookEditor
                  value={settings.sheetWebhookUrl}
                  onSave={(url) => save({ ...settings, sheetWebhookUrl: url })}
                />
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function SheetWebhookEditor({
  value,
  onSave,
}: {
  value: string;
  onSave: (v: string) => void;
}) {
  const [draft, setDraft] = useState(value);
  const [savedFlash, setSavedFlash] = useState(false);
  const dirty = draft.trim() !== value.trim();

  const commit = () => {
    onSave(draft.trim());
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 1500);
  };

  const clear = () => {
    setDraft("");
    onSave("");
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 1500);
  };

  const isValid = draft.trim() === "" || /^https?:\/\//i.test(draft.trim());

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-border bg-background/60 p-3 text-[11px] leading-relaxed text-muted-foreground">
        <p className="mb-1 font-semibold text-foreground">Google Apps Script Webhook</p>
        <p>
          নতুন সিরিয়াল সেভ বা ডিলিট হলে এই URL-এ automatically backup যাবে।
          Sheet পরিবর্তন করতে চাইলে নতুন Apps Script link এখানে paste করুন,
          কোড change করার দরকার নেই।
        </p>
      </div>

      <Labeled label="Webhook URL">
        <input
          type="url"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="https://script.google.com/macros/s/..../exec"
          className="input-premium text-xs"
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
        />
      </Labeled>

      {!isValid && (
        <p className="text-[11px] text-destructive">URL অবশ্যই https:// দিয়ে শুরু হবে</p>
      )}

      <div className="flex gap-2">
        <button
          onClick={commit}
          disabled={!dirty || !isValid}
          className="btn-premium flex-1 rounded-xl py-2.5 text-sm font-semibold disabled:opacity-50"
        >
          {savedFlash ? "✓ সেভ হয়েছে" : "সেভ করুন"}
        </button>
        {value && (
          <button
            onClick={clear}
            className="rounded-xl border border-border bg-background px-3 text-sm font-semibold hover:bg-secondary"
          >
            Clear
          </button>
        )}
      </div>

      <button
        onClick={() => {
          setDraft(DEFAULT_SETTINGS.sheetWebhookUrl);
        }}
        className="w-full rounded-lg border border-border py-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground hover:bg-secondary"
      >
        Default URL এ ফিরে যান
      </button>
    </div>
  );
}



function Labeled({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </label>
      {children}
    </div>
  );
}

function Switch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 shrink-0 rounded-full border transition-colors ${
        checked ? "border-primary bg-primary" : "border-border bg-secondary"
      }`}
    >
      <span
        className={`absolute top-0.5 h-4 w-4 rounded-full bg-card shadow transition-transform ${
          checked ? "translate-x-[22px]" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}

function SuggestionList({
  items,
  onUpdate,
  addPlaceholder,
  clearLabel,
}: {
  items: string[];
  onUpdate: (next: string[]) => void;
  addPlaceholder: string;
  clearLabel: string;
}) {
  const [draft, setDraft] = useState("");
  const [editing, setEditing] = useState<number | null>(null);
  const [editValue, setEditValue] = useState("");
  const [query, setQuery] = useState("");

  const add = () => {
    const v = draft.trim();
    if (!v) return;
    if (items.some((n) => n.toLowerCase() === v.toLowerCase())) {
      setDraft("");
      return;
    }
    onUpdate([v, ...items]);
    setDraft("");
  };

  const remove = (i: number) => {
    const next = items.filter((_, idx) => idx !== i);
    onUpdate(next);
  };

  const saveEdit = (i: number) => {
    const v = editValue.trim();
    if (!v) {
      setEditing(null);
      return;
    }
    const next = items.map((it, idx) => (idx === i ? v : it));
    onUpdate(next);
    setEditing(null);
  };

  const filtered = query.trim()
    ? items
        .map((v, i) => ({ v, i }))
        .filter(({ v }) => v.toLowerCase().includes(query.trim().toLowerCase()))
    : items.map((v, i) => ({ v, i }));

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              add();
            }
          }}
          placeholder={addPlaceholder}
          className="input-premium flex-1"
        />
        <button
          onClick={add}
          className="rounded-xl border border-primary bg-primary px-4 text-sm font-semibold text-primary-foreground hover:opacity-90"
        >
          +
        </button>
      </div>

      {items.length > 4 && (
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="খুঁজুন…"
          className="input-premium"
        />
      )}

      <div className="max-h-56 space-y-1.5 overflow-y-auto pr-1">
        {filtered.length === 0 ? (
          <p className="py-4 text-center text-xs text-muted-foreground">কিছু নেই</p>
        ) : (
          filtered.map(({ v, i }) => (
            <div
              key={`${v}-${i}`}
              className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-1.5"
            >
              {editing === i ? (
                <>
                  <input
                    autoFocus
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") { e.preventDefault(); saveEdit(i); }
                      if (e.key === "Escape") setEditing(null);
                    }}
                    className="input-premium flex-1 py-1.5"
                  />
                  <button
                    onClick={() => saveEdit(i)}
                    className="rounded-md p-1.5 text-primary hover:bg-secondary"
                    aria-label="Save"
                  >
                    <Check className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setEditing(null)}
                    className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary"
                    aria-label="Cancel"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </>
              ) : (
                <>
                  <span className="flex-1 truncate text-sm">{v}</span>
                  <button
                    onClick={() => {
                      setEditing(i);
                      setEditValue(v);
                    }}
                    className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-primary"
                    aria-label="Edit"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => remove(i)}
                    className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-destructive"
                    aria-label="Delete"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </>
              )}
            </div>
          ))
        )}
      </div>

      {items.length > 0 && (
        <button
          onClick={() => {
            if (confirm("শুধু এই সাজেশনগুলো মুছবেন? সিরিয়াল লিস্ট এতে মুছবে না।")) onUpdate([]);
          }}
          className="w-full rounded-lg border border-destructive/40 py-2 text-xs font-semibold uppercase tracking-wider text-destructive hover:bg-destructive/10"
        >
          {clearLabel}
        </button>
      )}
    </div>
  );
}

function SmsTemplateEditor({ value, onSave }: { value: string; onSave: (v: string) => void }) {
  const [draft, setDraft] = useState(value);
  const [savedFlash, setSavedFlash] = useState(false);
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const dirty = draft !== value;

  const commit = (v: string) => {
    onSave(v);
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 1500);
  };

  return (
    <div className="space-y-3">
      <Labeled label="SMS টেমপ্লেট">
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          rows={7}
          className="input-premium resize-none text-sm leading-relaxed"
        />
      </Labeled>
      <div className="rounded-xl border border-border bg-background/60 p-3 text-[11px] leading-relaxed text-muted-foreground">
        <p className="mb-1 font-semibold text-foreground">উপলব্ধ ভ্যারিয়েবল:</p>
        <p><code className="text-primary">{"{patient_name}"}</code> — রোগীর নাম</p>
        <p><code className="text-primary">{"{serial}"}</code> — চেম্বার-দিনের সিরিয়াল (১ থেকে)</p>
        <p><code className="text-primary">{"{est_time}"}</code> — আনুমানিক সময়</p>
        <p><code className="text-primary">{"{chamber_day}"}</code> — চেম্বারের দিন (রবি/মঙ্গল/বুধ/শুক্র)</p>
      </div>
      <button
        onClick={() => commit(draft)}
        disabled={!dirty && !savedFlash}
        className="w-full rounded-xl bg-primary py-2.5 text-xs font-semibold text-primary-foreground disabled:opacity-60"
      >
        {savedFlash ? "✓ সেভ হয়েছে" : dirty ? "সেভ করুন" : "সেভড"}
      </button>

      <button
        onClick={() => {
          setAdvancedOpen((v) => !v);
          setConfirmReset(false);
        }}
        className="flex w-full items-center justify-between rounded-xl border border-border bg-background px-3 py-2.5 text-xs font-medium hover:bg-secondary"
      >
        <span className="flex items-center gap-2">
          <Sliders className="h-3.5 w-3.5" />
          Advanced
        </span>
        <ChevronRight className={`h-4 w-4 transition-transform ${advancedOpen ? "rotate-90" : ""}`} />
      </button>

      {advancedOpen && (
        <div className="rounded-xl border border-border bg-background/60 p-3 space-y-2 animate-in fade-in slide-in-from-top-1 duration-200">
          {!confirmReset ? (
            <button
              onClick={() => setConfirmReset(true)}
              className="w-full rounded-lg border border-border bg-background py-2 text-xs font-medium text-muted-foreground hover:text-foreground"
            >
              ডিফল্ট টেমপ্লেটে ফিরে যান
            </button>
          ) : (
            <div className="space-y-2">
              <p className="text-xs text-foreground">
                নিশ্চিত? বর্তমান টেমপ্লেট মুছে গিয়ে ডিফল্টে ফিরে যাবে।
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setConfirmReset(false)}
                  className="rounded-lg border border-border bg-background py-1.5 text-xs font-semibold hover:bg-secondary"
                >
                  বাতিল
                </button>
                <button
                  onClick={() => {
                    setDraft(DEFAULT_SETTINGS.smsTemplate);
                    commit(DEFAULT_SETTINGS.smsTemplate);
                    setConfirmReset(false);
                  }}
                  className="rounded-lg bg-destructive py-1.5 text-xs font-semibold text-destructive-foreground"
                >
                  হ্যাঁ, রিসেট
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ChamberClosedPanel({
  template,
  onSaveTemplate,
}: {
  template: string;
  onSaveTemplate: (tpl: string) => void;
}) {
  const { drums } = useDrums();
  const [draft, setDraft] = useState(template);
  const [savedFlash, setSavedFlash] = useState(false);
  const [confirmSend, setConfirmSend] = useState(false);
  const [sending, setSending] = useState(false);

  const uniqueNumbers = Array.from(
    new Set(
      drums
        .map((d) => (d.mobile_number ?? "").replace(/\D/g, ""))
        .filter((n) => n.length === 11),
    ),
  );

  const dirty = draft.trim() !== template.trim();
  const canSend = uniqueNumbers.length > 0 && draft.trim().length > 0 && !sending;

  const commit = () => {
    onSaveTemplate(draft.trim());
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 1500);
  };

  const send = async () => {
    setSending(true);
    try {
      const res = await sendBulkSmsMany({
        data: { numbers: uniqueNumbers, message: draft.trim() },
      });
      if (res.ok) {
        toast.success(`${res.sent} জনকে SMS পাঠানো হয়েছে`);
      } else {
        toast.error(`SMS পাঠানো যায়নি${res.code ? ` (কোড ${res.code})` : ""}`);
      }
    } catch {
      toast.error("SMS পাঠানো যায়নি");
    } finally {
      setSending(false);
      setConfirmSend(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-border bg-background/60 p-3 text-[11px] leading-relaxed text-muted-foreground">
        <p className="mb-1 font-semibold text-foreground">চেম্বার বন্ধ ঘোষণা</p>
        <p>
          ডাক্তার আজ না বসলে, নিচের বার্তাটি এক ক্লিকে সব রোগীর মোবাইলে পাঠানো যাবে।
          মোবাইল নাম্বার আছে এমন সিরিয়াল থেকে unique নাম্বার নেওয়া হবে।
        </p>
      </div>

      <Labeled label="বার্তা">
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          rows={5}
          className="input-premium resize-y text-sm leading-relaxed"
        />
      </Labeled>

      <div className="flex items-center justify-between rounded-lg border border-border bg-background/60 px-3 py-2 text-xs">
        <span className="text-muted-foreground">প্রাপক (unique মোবাইল)</span>
        <span className="font-semibold tabular text-foreground">{uniqueNumbers.length} জন</span>
      </div>

      <div className="flex gap-2">
        <button
          onClick={commit}
          disabled={!dirty}
          className="flex-1 rounded-xl border border-border bg-background py-2.5 text-sm font-semibold hover:bg-secondary disabled:opacity-50"
        >
          {savedFlash ? "✓ সেভ হয়েছে" : "টেমপ্লেট সেভ"}
        </button>
        <button
          onClick={() => setDraft(DEFAULT_CHAMBER_CLOSED_TEMPLATE)}
          className="rounded-xl border border-border bg-background px-3 text-xs font-semibold hover:bg-secondary"
        >
          Default
        </button>
      </div>

      {!confirmSend ? (
        <button
          onClick={() => setConfirmSend(true)}
          disabled={!canSend}
          className="btn-premium flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold disabled:opacity-50"
        >
          <BellOff className="h-4 w-4" />
          সবাইকে জানান ({uniqueNumbers.length})
        </button>
      ) : (
        <div className="space-y-2 rounded-xl border border-destructive/40 bg-destructive/5 p-3">
          <p className="text-xs font-medium text-foreground">
            {uniqueNumbers.length} জন রোগীকে এই বার্তা পাঠানো হবে। নিশ্চিত?
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setConfirmSend(false)}
              disabled={sending}
              className="flex-1 rounded-lg border border-border bg-background py-2 text-xs font-semibold hover:bg-secondary"
            >
              বাতিল
            </button>
            <button
              onClick={send}
              disabled={sending}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-destructive py-2 text-xs font-semibold text-destructive-foreground disabled:opacity-70"
            >
              {sending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              {sending ? "পাঠাচ্ছে…" : "হ্যাঁ, পাঠাও"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
