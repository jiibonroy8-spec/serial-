import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { FolderOpen, Loader2, RefreshCw, Smartphone, Upload, Check, X } from "lucide-react";
import {
  listCallRecordings,
  processPendingRecordings,
  uploadCallRecording,
  confirmCallRecording,
  dismissCallRecording,
  type CallRecording,
} from "@/lib/call-recordings.functions";
import {
  ensureFolderPermission,
  fileKey,
  fileToBase64,
  getSavedFolder,
  listNewRecordings,
  markSeen,
  pickRecordingsFolder,
  supportsFolderPicker,
} from "@/lib/recording-folder";

export function CallRecordingPanel({ onSerialCreated }: { onSerialCreated?: () => void }) {
  const [busy, setBusy] = useState<string | null>(null);
  const [folderName, setFolderName] = useState<string | null>(null);
  const [recordings, setRecordings] = useState<CallRecording[]>([]);
  const fileInput = useRef<HTMLInputElement>(null);
  // Resolved after mount so server and client render the same markup.
  const [canPickFolder, setCanPickFolder] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const rows = await listCallRecordings();
      setRecordings(rows);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    setCanPickFolder(supportsFolderPicker());
    refresh();
    getSavedFolder().then((h) => setFolderName(h?.name ?? null));
  }, [refresh]);

  const uploadFiles = useCallback(
    async (files: File[], seenKeys?: string[]) => {
      let created = 0;
      let review = 0;
      for (const file of files) {
        setBusy(`${file.name} প্রসেস হচ্ছে…`);
        try {
          const base64 = await fileToBase64(file);
          const res = await uploadCallRecording({
            data: { base64, filename: file.name, fileType: file.type || "audio/m4a" },
          });
          if (!res.ok) {
            toast.error(`${file.name}: আপলোড হয়নি`);
            continue;
          }
          if (res.status === "serial_created") created += 1;
          else if (res.status === "needs_review") review += 1;
        } catch {
          toast.error(`${file.name}: প্রসেস করা যায়নি`);
        }
      }
      if (seenKeys?.length) markSeen(seenKeys);
      setBusy(null);
      await refresh();
      if (created) {
        toast.success(`${created} টি সিরিয়াল তৈরি হয়েছে`);
        onSerialCreated?.();
      }
      if (review) toast.warning(`${review} টি রেকর্ডিং যাচাই করতে হবে`);
      if (!created && !review && files.length) toast.info("নতুন কিছু পাওয়া যায়নি");
    },
    [refresh, onSerialCreated],
  );

  const scanFolder = useCallback(async () => {
    let handle = await getSavedFolder();
    if (!handle) {
      toast.error("আগে ফোল্ডার নির্বাচন করুন");
      return;
    }
    const allowed = await ensureFolderPermission(handle);
    if (!allowed) {
      toast.error("ফোল্ডারের অনুমতি দিন");
      return;
    }
    setBusy("ফোল্ডার স্ক্যান হচ্ছে…");
    try {
      const files = await listNewRecordings(handle);
      if (files.length === 0) {
        setBusy(null);
        toast.info("নতুন রেকর্ডিং নেই");
        return;
      }
      await uploadFiles(files, files.map(fileKey));
    } catch {
      setBusy(null);
      toast.error("ফোল্ডার পড়া যায়নি");
    }
  }, [uploadFiles]);

  const choose = useCallback(async () => {
    try {
      const handle = await pickRecordingsFolder();
      if (handle) {
        setFolderName(handle.name);
        toast.success("ফোল্ডার সেভ হয়েছে");
      }
    } catch {
      /* user cancelled */
    }
  }, []);

  const pending = recordings.filter((r) => r.processing_status === "needs_review");
  const failed = recordings.filter((r) => r.processing_status === "failed");
  const autoCount = recordings.filter((r) => r.processing_status === "serial_created").length;

  return (
    <section className="mb-3 overflow-hidden rounded-2xl border border-sky-500/30 bg-sky-500/10 p-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-base font-semibold text-foreground">কল রেকর্ডিং</h2>
          <p className="text-xs text-muted-foreground">
            রেকর্ডিং থেকে স্বয়ংক্রিয় সিরিয়াল · মোট {autoCount} টি
            {folderName ? ` · ফোল্ডার: ${folderName}` : ""}
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            setBusy("পুরনো রেকর্ডিং প্রসেস হচ্ছে…");
            processPendingRecordings()
              .then(async () => {
                await refresh();
                toast.success("প্রসেস সম্পন্ন");
                onSerialCreated?.();
              })
              .catch(() => toast.error("প্রসেস করা যায়নি"))
              .finally(() => setBusy(null));
          }}
          aria-label="আবার প্রসেস"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-border bg-card text-foreground hover:bg-secondary"
        >
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        {canPickFolder ? (
          <>
            <button
              type="button"
              onClick={choose}
              className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-3 py-2 text-xs font-semibold text-foreground hover:bg-secondary"
            >
              <FolderOpen className="h-4 w-4" />
              ফোল্ডার নির্বাচন
            </button>
            <button
              type="button"
              onClick={scanFolder}
              disabled={Boolean(busy)}
              className="btn-premium inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold disabled:opacity-50"
            >
              <RefreshCw className="h-4 w-4" />
              অটো স্ক্যান
            </button>
          </>
        ) : null}
        <button
          type="button"
          onClick={() => fileInput.current?.click()}
          disabled={Boolean(busy)}
          className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-3 py-2 text-xs font-semibold text-foreground hover:bg-secondary disabled:opacity-50"
        >
          {canPickFolder ? <Upload className="h-4 w-4" /> : <Smartphone className="h-4 w-4" />}
          রেকর্ডিং নির্বাচন
        </button>
        <input
          ref={fileInput}
          type="file"
          accept=".m4a,.mp3,.wav,.mp4,.aac,audio/*"
          multiple
          className="hidden"
          onChange={async (e) => {
            const files = Array.from(e.target.files ?? []);
            e.target.value = "";
            if (files.length) await uploadFiles(files);
          }}
        />
      </div>

      {busy && (
        <p className="mt-2 inline-flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
          {busy}
        </p>
      )}

      {failed.length > 0 && (
        <p className="mt-2 text-xs text-destructive">{failed.length} টি রেকর্ডিং প্রসেস হয়নি</p>
      )}

      {pending.length > 0 && (
        <ul className="mt-3 space-y-2">
          {pending.map((rec) => (
            <ReviewCard
              key={rec.id}
              rec={rec}
              onDone={async () => {
                await refresh();
                onSerialCreated?.();
              }}
            />
          ))}
        </ul>
      )}
    </section>
  );
}

function ReviewCard({ rec, onDone }: { rec: CallRecording; onDone: () => void }) {
  const [name, setName] = useState(rec.extracted_name ?? "");
  const [village, setVillage] = useState(rec.extracted_village ?? "");
  const [mobile, setMobile] = useState(rec.extracted_mobile ?? "");
  const [saving, setSaving] = useState(false);

  return (
    <li className="rounded-xl border border-amber-500/40 bg-card p-3">
      <p className="text-xs font-semibold text-amber-600">যাচাই প্রয়োজন — {rec.original_filename}</p>
      {rec.transcript && (
        <p className="mt-1 line-clamp-3 text-[11px] text-muted-foreground">{rec.transcript}</p>
      )}
      <div className="mt-2 grid gap-2 sm:grid-cols-3">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="নাম"
          className="rounded-lg border border-border bg-background px-2.5 py-2 text-sm"
        />
        <input
          value={village}
          onChange={(e) => setVillage(e.target.value)}
          placeholder="গ্রাম"
          className="rounded-lg border border-border bg-background px-2.5 py-2 text-sm"
        />
        <input
          value={mobile}
          onChange={(e) => setMobile(e.target.value)}
          placeholder="মোবাইল"
          inputMode="numeric"
          className="tabular rounded-lg border border-border bg-background px-2.5 py-2 text-sm"
        />
      </div>
      <div className="mt-2 flex gap-2">
        <button
          type="button"
          disabled={saving}
          onClick={async () => {
            setSaving(true);
            const res = await confirmCallRecording({ data: { id: rec.id, name, village, mobile } });
            setSaving(false);
            if (res.ok) {
              toast.success("সিরিয়াল তৈরি হয়েছে");
              onDone();
            } else {
              toast.error("অন্তত নাম লিখুন");
            }
          }}
          className="btn-premium inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold disabled:opacity-50"
        >
          <Check className="h-3.5 w-3.5" />
          সিরিয়াল তৈরি
        </button>
        <button
          type="button"
          onClick={async () => {
            await dismissCallRecording({ data: { id: rec.id } });
            onDone();
          }}
          className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-secondary"
        >
          <X className="h-3.5 w-3.5" />
          বাদ দিন
        </button>
      </div>
    </li>
  );
}
