import { useEffect, useSyncExternalStore } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  syncAddToSheet,
  syncDeleteToSheet,
  syncReplaceSheet,
  syncResetSheet,
} from "@/lib/sheet-sync";

export type Drum = {
  id: string;
  serial_number: number;
  customer_name: string;
  drum_number: string | null;
  village: string | null;
  mobile_number: string | null;
  sms_sent: boolean;
  created_at: string;
  source?: string | null;
  call_recording_id?: string | null;
};


export type DrumInput = {
  customer_name: string;
  village?: string | null;
  mobile_number?: string | null;
  drum_number?: string | null;
};

function sortDesc(a: Drum, b: Drum) {
  return b.serial_number - a.serial_number;
}

// ---------- Module-level singleton store ----------
// Prevents refetching + resubscribing every time a route mounts,
// which is what caused the laggy feel switching pages.
type State = { drums: Drum[]; loading: boolean };
let state: State = { drums: [], loading: true };
const listeners = new Set<() => void>();

function setState(next: Partial<State> | ((s: State) => State)) {
  state = typeof next === "function" ? next(state) : { ...state, ...next };
  listeners.forEach((l) => l());
}
function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}
function getSnapshot() {
  return state;
}

function wait(ms: number) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function isTransientSaveError(error: { code?: string; message?: string } | null) {
  if (!error) return false;
  if (error.code === "23505" || error.code === "40001" || error.code === "40P01") return true;
  const message = error.message?.toLowerCase() ?? "";
  return message.includes("timeout") || message.includes("network") || message.includes("fetch");
}

let initialized = false;
let channel: ReturnType<typeof supabase.channel> | null = null;

export async function reloadDrums() {
  const { data, error } = await supabase
    .from("drums")
    .select("*")
    .order("serial_number", { ascending: false });
  if (error) return;
  setState({ drums: (data as Drum[]) ?? [], loading: false });
}

function init() {
  if (initialized) return;
  initialized = true;

  supabase
    .from("drums")
    .select("*")
    .order("serial_number", { ascending: false })
    .then(({ data, error }) => {
      if (error) toast.error(error.message);
      setState({ drums: (data as Drum[]) ?? [], loading: false });
    });

  channel = supabase
    .channel("drums-live")
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "drums" },
      (payload) => {
        setState((s) => {
          let drums = s.drums;
          if (payload.eventType === "INSERT") {
            const row = payload.new as Drum;
            if (drums.some((d) => d.id === row.id)) return s;
            drums = [row, ...drums].sort(sortDesc);
          } else if (payload.eventType === "DELETE") {
            const row = payload.old as Drum;
            if (!drums.some((d) => d.id === row.id)) return s;
            drums = drums.filter((d) => d.id !== row.id);
          } else if (payload.eventType === "UPDATE") {
            const row = payload.new as Drum;
            const existing = drums.find((d) => d.id === row.id);
            // Skip no-op updates (already applied via optimistic path).
            // Cheap shallow compare of the fields we care about.
            if (
              existing &&
              existing.serial_number === row.serial_number &&
              existing.customer_name === row.customer_name &&
              existing.village === row.village &&
              existing.mobile_number === row.mobile_number &&
              existing.drum_number === row.drum_number &&
              existing.sms_sent === row.sms_sent
            ) {
              return s;
            }
            drums = drums.map((d) => (d.id === row.id ? row : d));
          }
          return { ...s, drums };
        });
      },
    )
    .subscribe();
}


async function addDrum(input: DrumInput): Promise<Drum | null> {
  let data: Drum | null = null;
  let error: { code?: string; message: string } | null = null;

  for (let attempt = 0; attempt < 3; attempt += 1) {
    const result = await supabase.rpc("add_drum_serial", {
      _customer_name: input.customer_name,
      _village: input.village ?? undefined,
      _mobile_number: input.mobile_number ?? undefined,
      _drum_number: input.drum_number ?? undefined,
    });
    data = result.data as Drum | null;
    error = result.error;
    if (!error) break;
    if (!isTransientSaveError(error) || attempt === 2) break;
    await wait(180 + attempt * 220);
  }

  if (error) {
    toast.error("সিরিয়াল সেভ হয়নি — আবার চেষ্টা করুন");
    return null;
  }
  if (!data) {
    toast.error("সিরিয়াল সেভ হয়নি — আবার চেষ্টা করুন");
    return null;
  }
  const row = data;
  setState((s) => ({
    ...s,
    drums: s.drums.some((d) => d.id === row.id)
      ? s.drums
      : [row, ...s.drums].sort(sortDesc),
  }));
  syncAddToSheet(row);
  return row;
}

async function updateDrum(id: string, patch: Partial<DrumInput>) {
  const { data, error } = await supabase
    .from("drums")
    .update(patch)
    .eq("id", id)
    .select("*")
    .single();
  if (error) {
    toast.error(error.message);
    return null;
  }
  const row = data as Drum;
  setState((s) => ({
    ...s,
    drums: s.drums.map((d) => (d.id === row.id ? row : d)),
  }));
  return row;
}

async function deleteDrum(id: string) {
  const target = state.drums.find((d) => d.id === id);
  if (!target) return false;
  const prev = state.drums;
  const removedSerial = target.serial_number;
  const hadHigherSerials = prev.some((d) => d.serial_number > removedSerial);
  const nextDrums = hadHigherSerials
    ? prev
        .filter((d) => d.id !== id)
        .map((d) =>
          d.serial_number > removedSerial
            ? { ...d, serial_number: d.serial_number - 1 }
            : d,
        )
    : prev.filter((d) => d.id !== id);
  setState({ drums: nextDrums });
  const { error } = await supabase.rpc("delete_and_resequence", { _id: id });
  if (error) {
    setState({ drums: prev });
    toast.error(error.message);
    return false;
  }
  syncDeleteToSheet({
    serial_number: target.serial_number,
    mobile_number: target.mobile_number,
  });
  // Only mirror the whole list when serials actually shifted.
  if (hadHigherSerials) syncReplaceSheet(nextDrums);
  return true;
}


async function resetAll() {
  const { error } = await supabase.rpc("reset_drums");
  if (error) {
    toast.error(error.message);
    return false;
  }
  setState({ drums: [] });
  syncResetSheet();
  return true;
}

async function markSmsSent(id: string, sent = true) {
  // optimistic
  setState((s) => ({
    ...s,
    drums: s.drums.map((d) => (d.id === id ? { ...d, sms_sent: sent } : d)),
  }));
  const { error } = await supabase.from("drums").update({ sms_sent: sent }).eq("id", id);
  if (error) toast.error(error.message);
}

export function useDrums() {
  const snap = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
  useEffect(() => {
    init();
  }, []);
  return {
    drums: snap.drums,
    loading: snap.loading,
    addDrum,
    updateDrum,
    deleteDrum,
    resetAll,
    markSmsSent,
  };
}


export function isToday(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  return (
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate()
  );
}

export function fmtTime(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export function fmtDate(iso: string) {
  return new Date(iso).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}
