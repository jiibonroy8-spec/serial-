import { useEffect, useState } from "react";
import { DEFAULT_SMS_TEMPLATE, DEFAULT_NEXT_SMS_TEMPLATE } from "@/lib/sms";
import {
  listSerialSuggestions,
  rememberSerialSuggestion,
  replaceSerialSuggestions,
} from "@/lib/serial-suggestions.functions";
import { SEED_NAMES, SEED_VILLAGES, SEED_MOBILES } from "@/lib/seed-suggestions";


export type ThemeId =
  | "noir-gold"
  | "ivory-ink"
  | "midnight-emerald"
  | "royal-sapphire"
  | "bordeaux-rose"
  | "graphite-mint";

export type Settings = {
  brandName: string;
  tagline: string;
  accentHue: number;
  theme: ThemeId;
  bulkSmsEnabled: boolean;
  smsTemplate: string;
  smsAppTemplate: string;
  nextSmsTemplate: string;
  chamberClosedTemplate: string;
  savedNames: string[];
  savedVillages: string[];
  savedMobiles: string[];
  sheetWebhookUrl: string;
};

export const DEFAULT_CHAMBER_CLOSED_TEMPLATE =
  "প্রিয় রোগী/অভিভাবক, আজ ডাঃ পরিমল রায়ের চেম্বার বন্ধ থাকবে। অসুবিধার জন্য দুঃখিত। পরবর্তী চেম্বারের দিনে আসার অনুরোধ রইল। — আস্থা ফার্মেসী, পীরগঞ্জ, ঠাকুরগাঁও। যোগাযোগ: ০১৭৬৩১১৫১১৫";


export const DEFAULT_SETTINGS: Settings = {
  brandName: "Doctor Serial",
  tagline: "Serial Management",
  accentHue: 82,
  theme: "ivory-ink",
  bulkSmsEnabled: false,
  smsTemplate: DEFAULT_SMS_TEMPLATE,
  smsAppTemplate: DEFAULT_SMS_TEMPLATE,
  nextSmsTemplate: DEFAULT_NEXT_SMS_TEMPLATE,
  chamberClosedTemplate: DEFAULT_CHAMBER_CLOSED_TEMPLATE,
  savedNames: SEED_NAMES,
  savedVillages: SEED_VILLAGES,
  savedMobiles: SEED_MOBILES,
  sheetWebhookUrl:
    "https://script.google.com/macros/s/AKfycbx8E_qzuTfpg3vxIsf-L9TqxAdwYgBUG_i2HqHtKNgwfaDgISXQu5yzdOWjVdUdwsJZ/exec",
};

export const THEME_PRESETS: {
  id: ThemeId;
  label: string;
  description: string;
  swatch: [string, string, string];
}[] = [
  { id: "noir-gold", label: "Noir & Gold", description: "Deep midnight paper, brass gold", swatch: ["#1a1610", "#2a221a", "#d4a84c"] },
  { id: "ivory-ink", label: "Ivory & Ink", description: "Warm cream, deep ink, gilded accents", swatch: ["#f5f0e6", "#e8dfce", "#8a6a2a"] },
  { id: "midnight-emerald", label: "Midnight Emerald", description: "Dark forest, jade accents", swatch: ["#0d1a16", "#152621", "#3fbf8f"] },
  { id: "royal-sapphire", label: "Royal Sapphire", description: "Deep navy, sapphire, platinum", swatch: ["#0e1428", "#182548", "#7aa8ff"] },
  { id: "bordeaux-rose", label: "Bordeaux & Rose", description: "Wine noir, rose gold", swatch: ["#1a1012", "#2a1418", "#e0a0a0"] },
  { id: "graphite-mint", label: "Graphite & Mint", description: "Cool slate, fresh mint", swatch: ["#151a1c", "#212a2d", "#7fe5c5"] },
];

function load(): Settings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem("drum.settings.v1");
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    const existingNames: string[] = Array.isArray(parsed.savedNames) ? parsed.savedNames : [];
    const existingVillages: string[] = Array.isArray(parsed.savedVillages) ? parsed.savedVillages : [];
    const existingMobiles: string[] = Array.isArray(parsed.savedMobiles) ? parsed.savedMobiles : [];
    const mergedNames = Array.from(new Set([...existingNames, ...DEFAULT_SETTINGS.savedNames]));
    const mergedVillages = Array.from(new Set([...existingVillages, ...DEFAULT_SETTINGS.savedVillages]));
    const mergedMobiles = Array.from(new Set([...existingMobiles, ...DEFAULT_SETTINGS.savedMobiles]));
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      savedNames: mergedNames,
      savedVillages: mergedVillages,
      savedMobiles: mergedMobiles,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

// Module-level shared store so every useSettings() consumer stays in sync.
let store: Settings = DEFAULT_SETTINGS;
let storeLoaded = false;
const listeners = new Set<() => void>();

function ensureLoaded() {
  if (storeLoaded) return;
  store = load();
  storeLoaded = true;
}

function persist(next: Settings) {
  store = next;
  try {
    localStorage.setItem("drum.settings.v1", JSON.stringify(next));
  } catch {
    /* ignore */
  }
  listeners.forEach((l) => l());
}

function unique(values: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const value of values) {
    const cleaned = value.trim();
    if (!cleaned) continue;
    const key = cleaned.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(cleaned);
  }
  return out;
}

function mergeSettings(next: Settings): Settings {
  const fresh = load();
  return {
    ...next,
    savedNames: unique([...(next.savedNames ?? []), ...fresh.savedNames]),
    savedVillages: unique([...(next.savedVillages ?? []), ...fresh.savedVillages]),
    savedMobiles: unique([...(next.savedMobiles ?? []), ...fresh.savedMobiles]),
  };
}

type SuggestionKind = "name" | "village" | "mobile";

async function syncSuggestionsFromBackend() {
  try {
    const rows = await listSerialSuggestions();
    const backendNames = rows.filter((r) => r.kind === "name").map((r) => r.value);
    const backendVillages = rows.filter((r) => r.kind === "village").map((r) => r.value);
    const backendMobiles = rows.filter((r) => r.kind === "mobile").map((r) => r.value);
    const mergedNames = unique([...backendNames, ...store.savedNames]);
    const mergedVillages = unique([...backendVillages, ...store.savedVillages]);
    const mergedMobiles = unique([...backendMobiles, ...store.savedMobiles]);
    persist({
      ...store,
      savedNames: mergedNames,
      savedVillages: mergedVillages,
      savedMobiles: mergedMobiles,
    });
    if (mergedNames.length > backendNames.length) backupSuggestionList("name", mergedNames);
    if (mergedVillages.length > backendVillages.length) backupSuggestionList("village", mergedVillages);
    if (mergedMobiles.length > backendMobiles.length) backupSuggestionList("mobile", mergedMobiles);
  } catch {
    // local saved suggestions still work offline; backend sync will retry on next open/save.
  }
}

function backupSuggestion(kind: SuggestionKind, value: string) {
  void rememberSerialSuggestion({ data: { kind, value } })
    .then(() => syncSuggestionsFromBackend())
    .catch(() => {
      /* keep local copy even if backend is temporarily unavailable */
    });
}

/** Re-read the permanent master lists (names / villages / mobiles) from the database. */
export function refreshSerialSuggestions() {
  ensureLoaded();
  return syncSuggestionsFromBackend();
}

function backupSuggestionList(kind: SuggestionKind, values: string[]) {
  void replaceSerialSuggestions({ data: { kind, values } }).catch(() => {
    /* keep local copy even if backend is temporarily unavailable */
  });
}

if (typeof window !== "undefined") {
  window.addEventListener("storage", (e) => {
    if (e.key !== "drum.settings.v1") return;
    store = load();
    listeners.forEach((l) => l());
  });
}

export function useSettings() {
  const [, setTick] = useState(0);
  const [loaded, setLoaded] = useState(storeLoaded);

  useEffect(() => {
    ensureLoaded();
    setLoaded(true);
    void syncSuggestionsFromBackend();
    const l = () => setTick((n) => n + 1);
    listeners.add(l);
    l();
    return () => {
      listeners.delete(l);
    };
  }, []);

  useEffect(() => {
    if (!loaded) return;
    if (typeof document === "undefined") return;
    document.documentElement.style.setProperty("--accent-hue", String(store.accentHue));
    document.documentElement.dataset.theme = store.theme;
  }, [loaded, store.accentHue, store.theme]);

  function save(next: Settings) {
    const merged = mergeSettings(next);
    const namesChanged = unique(next.savedNames ?? []).join("\n") !== unique(store.savedNames).join("\n");
    const villagesChanged = unique(next.savedVillages ?? []).join("\n") !== unique(store.savedVillages).join("\n");
    const mobilesChanged = unique(next.savedMobiles ?? []).join("\n") !== unique(store.savedMobiles ?? []).join("\n");
    persist(merged);
    if (namesChanged) backupSuggestionList("name", merged.savedNames);
    if (villagesChanged) backupSuggestionList("village", merged.savedVillages);
    if (mobilesChanged) backupSuggestionList("mobile", merged.savedMobiles);
  }

  function rememberName(name: string) {
    const v = name.trim();
    if (!v) return;
    ensureLoaded();
    if (store.savedNames.some((n) => n.toLowerCase() === v.toLowerCase())) return;
    persist({ ...store, savedNames: [v, ...store.savedNames] });
    backupSuggestion("name", v);
  }

  function rememberVillage(village: string) {
    const v = village.trim();
    if (!v) return;
    ensureLoaded();
    if (store.savedVillages.some((n) => n.toLowerCase() === v.toLowerCase())) return;
    persist({ ...store, savedVillages: [v, ...store.savedVillages] });
    backupSuggestion("village", v);
  }

  function rememberMobile(mobile: string) {
    const v = mobile.trim();
    if (!v) return;
    ensureLoaded();
    const list = store.savedMobiles ?? [];
    if (list.some((n) => n === v)) return;
    persist({ ...store, savedMobiles: [v, ...list] });
    backupSuggestion("mobile", v);
  }

  function replaceSavedNames(savedNames: string[]) {
    ensureLoaded();
    const next = unique(savedNames);
    persist({ ...store, savedNames: next });
    backupSuggestionList("name", next);
  }

  function replaceSavedVillages(savedVillages: string[]) {
    ensureLoaded();
    const next = unique(savedVillages);
    persist({ ...store, savedVillages: next });
    backupSuggestionList("village", next);
  }

  function replaceSavedMobiles(savedMobiles: string[]) {
    ensureLoaded();
    const next = unique(savedMobiles);
    persist({ ...store, savedMobiles: next });
    backupSuggestionList("mobile", next);
  }

  return {
    settings: store,
    save,
    rememberName,
    rememberVillage,
    rememberMobile,
    replaceSavedNames,
    replaceSavedVillages,
    replaceSavedMobiles,
  };
}
