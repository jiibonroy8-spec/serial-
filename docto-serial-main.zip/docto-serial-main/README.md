# Doctor serial

> Build a clean, mobile-responsive Serial Management web app for tracking "Drum" entries. The app will be used by two users (me and my assistant) on our mobile phones.

> **Key Features & UI Requirements:**

>  1. **Input Form:** A simple form with two fields: "Customer Name" (Text) and "Drum Number" (Number/Text).

>  2. **Submit Button:** A prominent button to save the entry.

>  3. **Auto-generated Data:** When submitted, the app must automatically generate a sequential "Serial Number" (starting from 1) and record the exact "Date & Time" (Timestamp).

>  4. **Live Counter:** A dashboard card at the top showing "Total Entries Today" (e.g., dynamically counting how many entries exist for the current day).

>  5. **Data Table/List:** A view below the form displaying today's submitted records (Serial, Name, Drum Number, Time).

> **Database & Integration:**

>  * Please use Supabase (your default backend) to store these records securely so that data syncs across both our phones in real-time.

>  * Include a feature or Webhook setup instruction so I can automatically sync or export this data to Google Sheets (I plan to use n8n or Zapier for the webhook).

> **Styling:**

> Make the UI modern, fast, and optimized for one-handed mobile use. Use a minimalist theme.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://docto-serial.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/d72f5e55-16e9-4f77-a481-a1495546b549).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
